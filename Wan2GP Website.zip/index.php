<?php
require_once 'includes/auth.php';

// If not logged in, redirect to login
if (!is_logged_in()) {
    header("Location: login.php");
    exit;
}

$user = get_current_user_data();

// If user is banned, force logout
if ($user && $user['is_banned']) {
    header("Location: logout.php?error=banned");
    exit;
}

// Get active skin
$stmt = $pdo->query("SELECT setting_value FROM site_settings WHERE setting_key = 'active_skin'");
$activeSkin = $stmt->fetchColumn() ?: 'default';
if (!preg_match('/^[a-zA-Z0-9_-]+$/', $activeSkin)) $activeSkin = 'default';
$skinCssPath = 'skins/' . $activeSkin . '/skin.css';
if (!file_exists(__DIR__ . '/' . $skinCssPath)) $skinCssPath = 'skins/default/skin.css';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wan2GP - Create Music</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/main.css">
    <link id="skin-css" rel="stylesheet" href="<?php echo $skinCssPath; ?>">
    <style>
        /* Specific Styles for Index Components */
        .user-profile {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
            border-radius: 16px;
            background: var(--bg-tertiary);
            cursor: pointer;
            margin-top: auto;
        }
        .user-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: linear-gradient(45deg, var(--accent-primary), var(--accent-secondary));
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 14px;
        }
        .credits-badge {
            background: rgba(236, 72, 153, 0.1);
            color: var(--accent-primary);
            padding: 4px 8px;
            border-radius: 8px;
            font-size: 12px;
            font-weight: 600;
        }
        
        /* Content Header */
        .content-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
        }
        .search-bar {
            background: var(--bg-secondary);
            border: 1px solid var(--border-color);
            padding: 10px 20px;
            border-radius: 99px;
            width: 300px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .search-bar input {
            background: transparent;
            border: none;
            color: white;
            outline: none;
            width: 100%;
        }

        /* Player Details */
        .player-track-info { display: flex; align-items: center; gap: 16px; width: 30%; }
        .track-img { width: 56px; height: 56px; border-radius: 8px; background: #333; flex-shrink: 0; display: block; background-size: cover; background-position: center; }
        .track-meta { overflow: hidden; }
        .track-meta h4 { font-size: 14px; margin-bottom: 4px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .track-meta p { font-size: 12px; color: var(--text-secondary); }

        .player-controls { display: flex; flex-direction: column; align-items: center; gap: 8px; width: 40%; }
        .control-btns { display: flex; align-items: center; gap: 24px; font-size: 20px; }
        .play-btn { width: 40px; height: 40px; border-radius: 50%; background: white; color: black; display: flex; align-items: center; justify-content: center; font-size: 16px; cursor: pointer; }
        
        .progress-container { width: 100%; display: flex; align-items: center; gap: 12px; font-size: 12px; color: var(--text-secondary); }
        .progress-bar { flex: 1; height: 4px; background: rgba(255,255,255,0.1); border-radius: 2px; position: relative; cursor: pointer; }
        .progress-fill { position: absolute; left: 0; top: 0; height: 100%; background: white; border-radius: 2px; width: 0%; transition: width 0.1s linear; }

        .player-actions { width: 30%; display: flex; justify-content: flex-end; align-items: center; gap: 16px; }
    </style>
</head>
<body>
    <!-- Toast Notifications -->
    <div id="toast-container" style="position: fixed; top: 24px; right: 24px; z-index: 10000; display: flex; flex-direction: column; gap: 12px;"></div>
    <style>
        .toast { background: var(--bg-secondary); border: 1px solid var(--border-color); border-radius: 16px; padding: 16px 20px; display: flex; align-items: center; gap: 12px; min-width: 300px; max-width: 400px; box-shadow: 0 10px 30px rgba(0,0,0,0.4); animation: slideIn 0.3s ease, fadeOut 0.3s ease 4.7s forwards; }
        .toast.success { border-color: #4ade80; }
        .toast.error { border-color: #f87171; }
        .toast.info { border-color: var(--accent-primary); }
        @keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        @keyframes fadeOut { to { opacity: 0; transform: translateY(-10px); } }
    </style>
    <script>
        function showToast(message, type = 'info') {
            const container = document.getElementById('toast-container');
            const toast = document.createElement('div');
            toast.className = 'toast ' + type;
            const icons = { success: 'fa-circle-check', error: 'fa-circle-xmark', info: 'fa-circle-info' };
            const colors = { success: '#4ade80', error: '#f87171', info: 'var(--accent-primary)' };
            toast.innerHTML = `<i class="fa-solid ${icons[type]}" style="color: ${colors[type]}; font-size: 18px;"></i><span style="font-size: 14px;">${message}</span>`;
            container.appendChild(toast);
            setTimeout(() => toast.remove(), 5000);
        }

        // Global background polling for pending songs (pings API every 10 seconds)
        window._pendingSongs = {};
        function formatElapsed(seconds) {
            const m = Math.floor(seconds / 60);
            const s = Math.floor(seconds % 60);
            return m > 0 ? `${m}m ${s}s` : `${s}s`;
        }

        function startPendingPoll(songId, songTitle, startedAt) {
            if (window._pendingSongs[songId]) return;
            window._pendingSongs[songId] = true;
            let failCount = 0;

            // Calculate elapsed time from created_at
            const startTime = startedAt ? new Date(startedAt).getTime() : Date.now();

            // Update elapsed timer every second
            const elapsedTimer = setInterval(() => {
                const elapsed = Math.floor((Date.now() - startTime) / 1000);
                const el = document.querySelector(`[data-song-id="${songId}"] .song-elapsed`);
                if (el) el.textContent = formatElapsed(elapsed);
                else clearInterval(elapsedTimer);
            }, 1000);
            if (window._activeIntervals) window._activeIntervals.push(elapsedTimer);

            // Ping API every 10 seconds
            const interval = setInterval(async () => {
                try {
                    const res = await fetch(`api/check_status.php?song_id=${songId}`);
                    const data = await res.json();
                    if (data.status === 'completed') {
                        clearInterval(interval);
                        clearInterval(elapsedTimer);
                        delete window._pendingSongs[songId];
                        showToast(`"${songTitle}" is ready!`, 'success');
                        if (window._activeIntervals) {
                            const idx = window._activeIntervals.indexOf(interval);
                            if (idx > -1) window._activeIntervals.splice(idx, 1);
                            const eidx = window._activeIntervals.indexOf(elapsedTimer);
                            if (eidx > -1) window._activeIntervals.splice(eidx, 1);
                        }
                        if (typeof loadWorkspaceSongs === 'function') loadWorkspaceSongs();
                        if (typeof refreshLibrary === 'function') refreshLibrary();
                    } else if (data.status === 'failed') {
                        clearInterval(interval);
                        clearInterval(elapsedTimer);
                        delete window._pendingSongs[songId];
                        showToast(`"${songTitle}" failed to generate.`, 'error');
                        if (window._activeIntervals) {
                            const idx = window._activeIntervals.indexOf(interval);
                            if (idx > -1) window._activeIntervals.splice(idx, 1);
                            const eidx = window._activeIntervals.indexOf(elapsedTimer);
                            if (eidx > -1) window._activeIntervals.splice(eidx, 1);
                        }
                        if (typeof loadWorkspaceSongs === 'function') loadWorkspaceSongs();
                        if (typeof refreshLibrary === 'function') refreshLibrary();
                    } else {
                        // Update elapsed from server time
                        if (data.started_at) {
                            const serverStart = new Date(data.started_at).getTime();
                            const elapsed = Math.floor((Date.now() - serverStart) / 1000);
                            const el = document.querySelector(`[data-song-id="${songId}"] .song-elapsed`);
                            if (el) el.textContent = formatElapsed(elapsed);
                        }
                        // Update progress bar and phase
                        const progress = data.progress || 0;
                        const phase = data.phase || '';
                        const progressBar = document.querySelector(`[data-song-id="${songId}"] .song-progress-fill`);
                        if (progressBar) progressBar.style.width = progress + '%';
                        const progressText = document.querySelector(`[data-song-id="${songId}"] .song-progress-text`);
                        if (progressText) progressText.textContent = progress + '%';
                        const phaseEl = document.querySelector(`[data-song-id="${songId}"] .song-phase`);
                        if (phaseEl) phaseEl.textContent = phase || 'Generating...';
                    }
                } catch (e) {
                    failCount++;
                    if (failCount > 30) {
                        clearInterval(interval);
                        clearInterval(elapsedTimer);
                        delete window._pendingSongs[songId];
                    }
                }
            }, 10000);
            if (window._activeIntervals) window._activeIntervals.push(interval);
        }

        // Check for any pending songs on load and start polling (works on ALL pages)
        async function checkAllPendingSongs() {
            try {
                const res = await fetch('api/get_pending_songs.php');
                const data = await res.json();
                if (data.success && data.songs) {
                    data.songs.forEach(song => {
                        startPendingPoll(song.id, song.title, song.created_at);
                    });
                }
            } catch(e) {}
        }
    </script>

    <div class="app-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="logo">Wan2GP</div>
            
            <nav class="nav-group">
                <a href="javascript:void(0)" class="nav-item active" onclick="loadPage('home')">
                    <i class="fa-solid fa-house"></i> Home
                </a>
                <a href="javascript:void(0)" class="nav-item" onclick="loadPage('create')">
                    <i class="fa-solid fa-wand-magic-sparkles"></i> Create
                </a>
                <a href="javascript:void(0)" class="nav-item" onclick="loadPage('library')">
                    <i class="fa-solid fa-music"></i> Library
                </a>
                <a href="javascript:void(0)" class="nav-item" onclick="loadPage('friends')">
                    <i class="fa-solid fa-user-group"></i> Friends
                </a>
                <a href="javascript:void(0)" class="nav-item" onclick="loadPage('explore')">
                    <i class="fa-solid fa-compass"></i> Explore
                </a>
                <a href="javascript:void(0)" class="nav-item" onclick="loadPage('users')">
                    <i class="fa-solid fa-users"></i> Users
                </a>
            </nav>

            <div class="nav-separator"></div>

            <div class="sidebar-footer">
                <a href="javascript:void(0)" class="sidebar-link" onclick="loadPage('profile')">
                    <i class="fa-solid fa-gear"></i> Settings
                </a>
                <?php if ($user['is_admin']): ?>
                <a href="javascript:void(0)" class="sidebar-link" onclick="loadPage('admin')">
                    <i class="fa-solid fa-shield-halved"></i> Admin
                </a>
                <?php endif; ?>
            </div>

            <div class="user-profile" onclick="loadPage('profile')">
                <?php $avatar = $user['avatar_url'] ?: 'assets/images/default-avatar.jpg'; ?>
                <div class="user-avatar" style="background-image: url('<?php echo $avatar; ?>'); background-size: cover; background-position: center;">
                </div>
                <div class="user-info">
                    <div class="name"><?php echo htmlspecialchars($user['username']); ?></div>
                    <div class="credits-badge" style="<?php echo (!$user['is_admin'] && $user['credits'] < 10) ? 'background: rgba(248,113,113,0.12); color: #f87171;' : ''; ?>"><?php echo $user['is_admin'] ? 'Unlimited' : ($user['credits'] . ' Credits'); ?></div>
                </div>
                <a href="logout.php" class="logout-btn" onclick="event.stopPropagation();" title="Logout">
                    <i class="fa-solid fa-right-from-bracket"></i>
                </a>
            </div>
        </aside>

        <!-- Create Panel (always visible) -->
        <aside class="create-panel" id="create-panel">
            <div class="create-tabs">
                <button class="create-tab active" data-tab="describe" onclick="switchCreateTab('describe')">Describe your song</button>
                <button class="create-tab" data-tab="custom" onclick="switchCreateTab('custom')">Custom</button>
            </div>

            <!-- Describe Tab -->
            <div id="tab-describe">
                <input type="text" class="title-input" id="cp-title" placeholder="Song title" value="">
                <textarea class="prompt-area" id="cp-prompt" placeholder="Acoustic folk with finger-picked guitar, warm cello, and gentle vocal harmonies"></textarea>
                <div class="tags-container" id="cp-tags-container">
                    <span class="tag-pill" onclick="toggleTag(this)">r&b</span>
                    <span class="tag-pill" onclick="toggleTag(this)">ambient sounds</span>
                    <span class="tag-pill" onclick="toggleTag(this)">german metal</span>
                    <span class="tag-pill" onclick="toggleTag(this)">lo-fi</span>
                    <span class="tag-pill" onclick="toggleTag(this)">jazz</span>
                    <span class="tag-pill" onclick="toggleTag(this)">classic</span>
                </div>
                <div class="toggle-row">
                    <label class="toggle-switch">
                        <input type="checkbox" id="cp-instrumental">
                        <span class="toggle-slider"></span>
                    </label>
                    <span class="toggle-label">Instrumental</span>
                </div>

                <div style="display: flex; gap: 8px; margin-top: 12px;">
                    <div style="flex: 1;">
                        <label style="font-size: 11px; color: var(--text-secondary); display: block; margin-bottom: 4px;">BPM</label>
                        <input type="number" id="cp-bpm" min="40" max="300" value="" placeholder="Auto" style="width: 100%; background: var(--bg-tertiary); border: 1px solid var(--border-color); border-radius: 8px; padding: 8px 10px; color: white; font-size: 13px; outline: none; box-sizing: border-box;">
                    </div>
                    <div style="flex: 1;">
                        <label style="font-size: 11px; color: var(--text-secondary); display: block; margin-bottom: 4px;">Key</label>
                        <select id="cp-key" style="width: 100%; background: var(--bg-tertiary); border: 1px solid var(--border-color); border-radius: 8px; padding: 8px 10px; color: white; font-size: 13px; outline: none; box-sizing: border-box;">
                            <option value="">Auto</option>
                            <option value="C major">C major</option><option value="C minor">C minor</option>
                            <option value="C# major">C# major</option><option value="C# minor">C# minor</option>
                            <option value="D major">D major</option><option value="D minor">D minor</option>
                            <option value="Eb major">Eb major</option><option value="Eb minor">Eb minor</option>
                            <option value="E major">E major</option><option value="E minor">E minor</option>
                            <option value="F major">F major</option><option value="F minor">F minor</option>
                            <option value="F# major">F# major</option><option value="F# minor">F# minor</option>
                            <option value="G major">G major</option><option value="G minor">G minor</option>
                            <option value="Ab major">Ab major</option><option value="Ab minor">Ab minor</option>
                            <option value="A major">A major</option><option value="A minor">A minor</option>
                            <option value="Bb major">Bb major</option><option value="Bb minor">Bb minor</option>
                            <option value="B major">B major</option><option value="B minor">B minor</option>
                        </select>
                    </div>
                    <div style="flex: 1;">
                        <label style="font-size: 11px; color: var(--text-secondary); display: block; margin-bottom: 4px;">Time</label>
                        <select id="cp-time" style="width: 100%; background: var(--bg-tertiary); border: 1px solid var(--border-color); border-radius: 8px; padding: 8px 10px; color: white; font-size: 13px; outline: none; box-sizing: border-box;">
                            <option value="">Auto</option>
                            <option value="4/4">4/4</option>
                            <option value="3/4">3/4</option>
                            <option value="6/8">6/8</option>
                            <option value="2/4">2/4</option>
                            <option value="5/4">5/4</option>
                            <option value="7/8">7/8</option>
                        </select>
                    </div>
                </div>

                <p class="lyric-hint" style="margin-top: 12px;">Want to write your own lyrics? <a href="javascript:void(0)" onclick="switchCreateTab('custom')">Use custom mode</a></p>
            </div>

            <!-- Custom Tab (hidden by default) -->
            <div id="tab-custom" style="display: none;">
                <input type="text" class="title-input" id="cp-title-custom" placeholder="Song title" value="">
                <textarea class="prompt-area" id="cp-custom-prompt" placeholder="Describe the style/mood (e.g., upbeat pop, sad ballad)" style="min-height: 60px; margin-bottom: 12px;"></textarea>
                <textarea class="prompt-area" id="cp-lyrics" placeholder="Enter your lyrics here..." style="min-height: 140px;"></textarea>
                <div class="toggle-row" style="margin-top: 12px;">
                    <label class="toggle-switch">
                        <input type="checkbox" id="cp-custom-instrumental">
                        <span class="toggle-slider"></span>
                    </label>
                    <span class="toggle-label">Instrumental</span>
                </div>

                <div style="display: flex; gap: 8px; margin-top: 12px;">
                    <div style="flex: 1;">
                        <label style="font-size: 11px; color: var(--text-secondary); display: block; margin-bottom: 4px;">BPM</label>
                        <input type="number" id="cp-custom-bpm" min="40" max="300" value="" placeholder="Auto" style="width: 100%; background: var(--bg-tertiary); border: 1px solid var(--border-color); border-radius: 8px; padding: 8px 10px; color: white; font-size: 13px; outline: none; box-sizing: border-box;">
                    </div>
                    <div style="flex: 1;">
                        <label style="font-size: 11px; color: var(--text-secondary); display: block; margin-bottom: 4px;">Key</label>
                        <select id="cp-custom-key" style="width: 100%; background: var(--bg-tertiary); border: 1px solid var(--border-color); border-radius: 8px; padding: 8px 10px; color: white; font-size: 13px; outline: none; box-sizing: border-box;">
                            <option value="">Auto</option>
                            <option value="C major">C major</option><option value="C minor">C minor</option>
                            <option value="C# major">C# major</option><option value="C# minor">C# minor</option>
                            <option value="D major">D major</option><option value="D minor">D minor</option>
                            <option value="Eb major">Eb major</option><option value="Eb minor">Eb minor</option>
                            <option value="E major">E major</option><option value="E minor">E minor</option>
                            <option value="F major">F major</option><option value="F minor">F minor</option>
                            <option value="F# major">F# major</option><option value="F# minor">F# minor</option>
                            <option value="G major">G major</option><option value="G minor">G minor</option>
                            <option value="Ab major">Ab major</option><option value="Ab minor">Ab minor</option>
                            <option value="A major">A major</option><option value="A minor">A minor</option>
                            <option value="Bb major">Bb major</option><option value="Bb minor">Bb minor</option>
                            <option value="B major">B major</option><option value="B minor">B minor</option>
                        </select>
                    </div>
                    <div style="flex: 1;">
                        <label style="font-size: 11px; color: var(--text-secondary); display: block; margin-bottom: 4px;">Time</label>
                        <select id="cp-custom-time" style="width: 100%; background: var(--bg-tertiary); border: 1px solid var(--border-color); border-radius: 8px; padding: 8px 10px; color: white; font-size: 13px; outline: none; box-sizing: border-box;">
                            <option value="">Auto</option>
                            <option value="4/4">4/4</option>
                            <option value="3/4">3/4</option>
                            <option value="6/8">6/8</option>
                            <option value="2/4">2/4</option>
                            <option value="5/4">5/4</option>
                            <option value="7/8">7/8</option>
                        </select>
                    </div>
                </div>
            </div>

            <button class="create-btn" id="cp-create-btn" onclick="createSong()">
                <i class="fa-solid fa-music"></i> Create
            </button>
        </aside>

        <!-- Main Content -->
        <main class="main-content" id="main-view">
            <header class="content-header">
                <h1 id="content-title">My Workspace</h1>
                <div class="search-bar">
                    <i class="fa-solid fa-magnifying-glass" style="color: var(--text-secondary);"></i>
                    <input type="text" id="global-search" placeholder="Search songs & users..." onkeydown="if(event.key==='Enter') doGlobalSearch()">
                </div>
            </header>
            <div id="content-body"></div>
        </main>

        <!-- Player Bar -->
        <footer class="player-bar">
            <div class="player-track-info">
                <div class="track-img"></div>
                <div class="track-meta">
                    <h4>No track selected</h4>
                    <p>Select a song to play</p>
                </div>
            </div>

            <div class="player-controls">
                <div class="control-btns">
                    <i class="fa-solid fa-shuffle" style="font-size: 14px; color: var(--text-secondary); cursor: pointer;"></i>
                    <i id="prev-btn" class="fa-solid fa-backward-step" style="cursor: pointer;"></i>
                    <div class="play-btn"><i class="fa-solid fa-play"></i></div>
                    <i id="next-btn" class="fa-solid fa-forward-step" style="cursor: pointer;"></i>
                    <i class="fa-solid fa-repeat" style="font-size: 14px; color: var(--text-secondary); cursor: pointer;"></i>
                </div>
                <div class="progress-container">
                    <span id="current-time">0:00</span>
                    <div class="progress-bar" id="progress-bar-container">
                        <div class="progress-fill"></div>
                    </div>
                    <span id="duration-time">0:00</span>
                </div>
            </div>

            <div class="player-actions">
                <i class="fa-solid fa-volume-high" id="volume-icon" style="cursor: pointer; width: 20px;"></i>
                <input type="range" id="volume-slider" min="0" max="1" step="0.01" value="0.7" style="width: 80px; accent-color: white; cursor: pointer;">
                <i class="fa-solid fa-list-ul" style="cursor: pointer;"></i>
            </div>
        </footer>
    </div>

    <!-- Site Rules Modal -->
    <?php if (!$user['rules_accepted']): 
        $stmt = $pdo->query("SELECT setting_value FROM site_settings WHERE setting_key = 'site_rules'");
        $rules_text = $stmt->fetchColumn() ?: 'Please follow the site rules.';
    ?>
    <div id="rules-modal" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.9); display: flex; align-items: center; justify-content: center; z-index: 9999; backdrop-filter: blur(12px);">
        <div style="background: var(--bg-secondary); padding: 48px; border-radius: 40px; max-width: 700px; width: 95%; border: 1px solid var(--border-color); box-shadow: 0 30px 60px rgba(0,0,0,0.6); display: flex; flex-direction: column; max-height: 85vh;">
            <div style="display: flex; align-items: center; gap: 16px; margin-bottom: 24px;">
                <div style="width: 48px; height: 48px; background: var(--accent-primary); border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 20px; color: white;">
                    <i class="fa-solid fa-gavel"></i>
                </div>
                <div>
                    <h2 style="font-size: 28px; font-weight: 800; line-height: 1;">Site Rules & Terms</h2>
                    <p style="color: var(--text-secondary); font-size: 14px; margin-top: 4px;">Please read and accept to continue</p>
                </div>
            </div>
            
            <div class="custom-scrollbar" style="background: var(--bg-tertiary); padding: 32px; border-radius: 24px; margin-bottom: 32px; font-size: 16px; line-height: 1.8; color: var(--text-primary); overflow-y: auto; flex: 1; white-space: pre-wrap;">
                <?php echo htmlspecialchars($rules_text); ?>
            </div>
            
            <button class="btn-primary" style="width: 100%; padding: 20px; font-size: 18px; border-radius: 20px; font-weight: 700; transition: transform 0.2s;" onclick="acceptRules()">
                Accept & Start Creating
            </button>
        </div>
    </div>
    <style>
    .custom-scrollbar::-webkit-scrollbar { width: 8px; }
    .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
    .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 10px; }
    .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: rgba(255,255,255,0.2); }
    </style>
    <script>
    async function acceptRules() {
        const res = await fetch('api/accept_rules.php', { method: 'POST' });
        const data = await res.json();
        if(data.success) {
            document.getElementById('rules-modal').style.display = 'none';
        }
    }
    </script>
    <?php endif; ?>

    <script>
        // Global fetch wrapper — always send session cookies
        const _origFetch = window.fetch;
        window.fetch = function(url, opts = {}) {
            opts.credentials = 'include';
            return _origFetch(url, opts);
        };

        window.BASE_URL = '<?php echo '/' . ltrim(BASE_URL, '/'); ?>';
        window._activeIntervals = [];
        function clearAllIntervals() {
            window._activeIntervals.forEach(id => clearInterval(id));
            window._activeIntervals = [];
            window._pendingSongs = {};
        }

        async function loadPage(page) {
            const contentBody = document.getElementById('content-body');
            const headerTitle = document.getElementById('content-title');
            
            clearAllIntervals();

            const createPanel = document.getElementById('create-panel');
            const appContainer = document.querySelector('.app-container');
            if (page === 'create' || page === 'library') {
                appContainer.classList.remove('panel-hidden');
                createPanel.style.display = '';
            } else {
                appContainer.classList.add('panel-hidden');
                createPanel.style.display = 'none';
            }

            document.querySelectorAll('.nav-item').forEach(item => {
                item.classList.remove('active');
                if(item.getAttribute('onclick').includes(page)) item.classList.add('active');
            });

            if (page === 'create') {
                headerTitle.textContent = 'My Workspace';
                contentBody.innerHTML = '<div id="workspace-songs"></div>';
                loadWorkspaceSongs();
                return;
            }

            const titles = { home: 'Home', library: 'My Library', explore: 'Explore', admin: 'Admin', profile: 'Settings', users: 'Users', search: 'Search Results', friends: 'Friends' };
            headerTitle.textContent = titles[page.split('&')[0]] || 'Users';

            contentBody.innerHTML = '<div style="display: flex; align-items: center; justify-content: center; height: 100%;"><div class="loader" style="width: 40px; height: 40px; border: 4px solid rgba(255,255,255,0.1); border-top-color: var(--accent-primary); border-radius: 50%; animation: spin 1s linear infinite;"></div></div>';

            try {
                let url = '';
                if (page === 'library') url = 'includes/library_view.php';
                else if (page === 'explore') url = 'includes/explore_view.php';
                else if (page === 'admin') url = 'includes/admin_view.php';
                else if (page === 'profile') url = 'includes/profile_view.php';
                else if (page.startsWith('user_profile')) url = 'includes/user_profile_view.php' + '?' + page.split('&').slice(1).join('&');
                else if (page.startsWith('users')) url = 'includes/users_view.php' + '?' + page.split('&').slice(1).join('&');
                else if (page.startsWith('search')) url = 'includes/search_view.php' + '?' + page.split('&').slice(1).join('&');
                else if (page === 'friends') url = 'includes/friends_view.php';
                else url = 'includes/home_view.php';

                const response = await fetch(url);
                const html = await response.text();
                contentBody.innerHTML = html;
                
                const scripts = contentBody.querySelectorAll('script');
                scripts.forEach(oldScript => {
                    const newScript = document.createElement('script');
                    Array.from(oldScript.attributes).forEach(attr => newScript.setAttribute(attr.name, attr.value));
                    newScript.appendChild(document.createTextNode(oldScript.innerHTML));
                    oldScript.parentNode.replaceChild(newScript, oldScript);
                });

                checkAllPendingSongs();

            } catch (err) {
                contentBody.innerHTML = '<div style="text-align: center; padding: 100px;"><h2>Failed to load page</h2><p>Please check your connection.</p></div>';
            }
        }

        function doGlobalSearch() {
            const q = document.getElementById('global-search').value.trim();
            if (q.length < 2) { showToast('Type at least 2 characters to search', 'info'); return; }
            loadPage('search&q=' + encodeURIComponent(q));
        }

        async function loadWorkspaceSongs() {
            try {
                const res = await fetch('api/get_songs.php?user_only=1');
                const data = await res.json();
                const songs = data.songs || [];
                const container = document.getElementById('workspace-songs');
                if (!songs.length) {
                    container.innerHTML = '<div style="text-align: center; padding: 80px 0; color: var(--text-secondary);"><i class="fa-solid fa-music" style="font-size: 48px; margin-bottom: 16px; display: block;"></i><p>No songs yet. Create your first song!</p></div>';
                    return;
                }
                container.innerHTML = songs.map(song => `
                    <div class="song-row" data-song-id="${song.id}">
                        <div class="song-row-img" style="background-image: url('${song.image_url || 'https://picsum.photos/seed/' + song.id + '/400/400'}');"></div>
                        <div class="song-row-info">
                            <div class="song-row-title">${song.title}</div>
                            <div class="song-row-meta">${song.status === 'completed' ? 'Complete' : song.status} • ${new Date(song.created_at).toLocaleDateString()}</div>
                        </div>
                        <div class="song-row-actions">
                            ${song.status === 'completed' ? `<button class="icon-btn" onclick="playSong(${song.id}, '${song.title}', '${song.image_url || 'https://picsum.photos/seed/' + song.id + '/400/400'}', '${song.audio_url}')"><i class="fa-solid fa-play"></i></button>` : ''}
                            ${song.status === 'pending' ? `<span class="song-elapsed">0s</span>` : ''}
                            ${song.status === 'failed' ? `<button class="icon-btn" style="color: #f87171;" onclick="deleteFailedSong(${song.id})" title="Remove"><i class="fa-solid fa-trash"></i></button>` : ''}
                        </div>
                    </div>
                `).join('');
                
                if (songs.some(s => s.status === 'pending')) {
                    songs.filter(s => s.status === 'pending').forEach(s => startPendingPoll(s.id, s.title, s.created_at));
                }
            } catch(e) {}
        }

        async function deleteFailedSong(songId) {
            try {
                const res = await fetch('api/delete_song.php?id=' + songId);
                const data = await res.json();
                if (data.success) {
                    loadWorkspaceSongs();
                } else {
                    showToast(data.error || 'Failed to delete', 'error');
                }
            } catch(e) { showToast('Network error', 'error'); }
        }

        // Create Panel Functions
        function switchCreateTab(tab) {
            document.querySelectorAll('.create-tab').forEach(t => t.classList.remove('active'));
            document.querySelector(`.create-tab[data-tab="${tab}"]`).classList.add('active');
            document.getElementById('tab-describe').style.display = tab === 'describe' ? 'block' : 'none';
            document.getElementById('tab-custom').style.display = tab === 'custom' ? 'block' : 'none';
        }

        function toggleTag(el) { el.classList.toggle('selected'); }

        async function createSong() {
            const activeTab = document.querySelector('.create-tab.active').dataset.tab;
            let prompt, lyrics, instrumental, title, bpm, musicalKey, timeSig;

            if (activeTab === 'describe') {
                title = document.getElementById('cp-title').value.trim() || 'Untitled Song';
                const selectedTags = Array.from(document.querySelectorAll('.tag-pill.selected')).map(t => t.textContent);
                prompt = document.getElementById('cp-prompt').value.trim() + (selectedTags.length ? '\nTags: ' + selectedTags.join(', ') : '');
                lyrics = '';
                instrumental = document.getElementById('cp-instrumental').checked;
                bpm = document.getElementById('cp-bpm').value || '';
                musicalKey = document.getElementById('cp-key').value || '';
                timeSig = document.getElementById('cp-time').value || '';
            } else {
                title = document.getElementById('cp-title-custom').value.trim() || 'Untitled Song';
                prompt = document.getElementById('cp-custom-prompt').value.trim();
                lyrics = document.getElementById('cp-lyrics').value.trim();
                instrumental = document.getElementById('cp-custom-instrumental').checked;
                bpm = document.getElementById('cp-custom-bpm').value || '';
                musicalKey = document.getElementById('cp-custom-key').value || '';
                timeSig = document.getElementById('cp-custom-time').value || '';
            }

            if (!prompt && !lyrics) { showToast('Please describe your song or enter lyrics', 'error'); return; }

            const btn = document.getElementById('cp-create-btn');
            btn.disabled = true;
            btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Creating...';

            try {
                const res = await fetch('api/generate.php', {
                    method: 'POST',
                    credentials: 'include',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ title, prompt, lyrics, instrumental, bpm, key: musicalKey, time_signature: timeSig, tags: Array.from(document.querySelectorAll('.tag-pill.selected')).map(t => t.textContent) })
                });
                const data = await res.json();
                if (data.error) { showToast(data.error, 'error'); return; }
                showToast(`"${data.title}" is generating!`, 'success');
                if (data.pending && data.pending.length) {
                    data.pending.forEach(s => startPendingPoll(s.id, s.title, s.created_at));
                }
                loadWorkspaceSongs();
                if (typeof refreshLibrary === 'function') refreshLibrary();
                // Auto-refresh workspace every 15s while pending songs exist
                if (!window._workspaceRefreshInterval) {
                    window._workspaceRefreshInterval = setInterval(() => {
                        if (Object.keys(window._pendingSongs).length === 0) {
                            clearInterval(window._workspaceRefreshInterval);
                            window._workspaceRefreshInterval = null;
                            return;
                        }
                        loadWorkspaceSongs();
                    }, 15000);
                }
            } catch(e) {
                showToast('Network error. Please try again.', 'error');
            } finally {
                btn.disabled = false;
                btn.innerHTML = '<i class="fa-solid fa-music"></i> Create';
            }
        }

        // Player Logic
        const audio = new Audio();
        const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        const source = audioCtx.createMediaElementSource(audio);
        const bassFilter = audioCtx.createBiquadFilter();
        bassFilter.type = 'lowshelf';
        bassFilter.frequency.value = 200;
        bassFilter.gain.value = -6;
        const gainNode = audioCtx.createGain();
        gainNode.gain.value = 2.5;
        source.connect(bassFilter);
        bassFilter.connect(gainNode);
        gainNode.connect(audioCtx.destination);
        let isPlaying = false;
        let currentPlaylist = [];
        let currentIndex = -1;

        // Save player state to localStorage
        function savePlayerState() {
            if (currentIndex >= 0 && currentPlaylist[currentIndex]) {
                const song = currentPlaylist[currentIndex];
                localStorage.setItem('playerState', JSON.stringify({
                    songId: song.id,
                    audio_url: song.audio_url,
                    title: song.title,
                    image_url: song.image_url,
                    currentTime: audio.currentTime,
                    volume: audio.volume,
                    index: currentIndex
                }));
            }
        }

        // Restore player state from localStorage
        function restorePlayerState() {
            try {
                const saved = localStorage.getItem('playerState');
                if (!saved) return false;
                const state = JSON.parse(saved);
                if (!state.audio_url) return false;

                // Set volume
                if (state.volume !== undefined) {
                    audio.volume = state.volume;
                    const volumeSlider = document.getElementById('volume-slider');
                    if (volumeSlider) volumeSlider.value = state.volume;
                }

                // Update UI
                document.querySelector('.track-meta h4').innerText = state.title || 'Untitled';
                document.querySelector('.track-meta p').innerText = 'Paused';
                const trackImgEl = document.querySelector('.track-img');
                const coverImg = state.image_url || 'assets/images/default-cover.jpg';
                trackImgEl.style.backgroundImage = `url("${coverImg}")`;
                trackImgEl.style.backgroundSize = 'cover';
                trackImgEl.style.backgroundPosition = 'center';

                // Load audio but don't play yet
                let audioUrl = state.audio_url;
                if (audioUrl && !audioUrl.startsWith('http') && !audioUrl.startsWith('data:')) {
                    audioUrl = window.location.origin + window.BASE_URL + '/' + audioUrl;
                }
                audio.src = audioUrl;
                audio.currentTime = state.currentTime || 0;

                return true;
            } catch(e) { return false; }
        }

        function updatePlayer(url, title, img, playlist = [], index = -1) {
            if (audioCtx.state === 'suspended') audioCtx.resume();
            if (url && !url.startsWith('http') && !url.startsWith('data:')) {
                url = window.location.origin + window.BASE_URL + '/' + url;
            }
            audio.src = url;
            document.querySelector('.track-meta h4').innerText = title || 'Untitled';
            document.querySelector('.track-meta p').innerText = 'Playing now';
            
            // Fallback for missing images
            const coverImg = img || 'assets/images/default-cover.jpg';
            const trackImgEl = document.querySelector('.track-img');
            trackImgEl.style.backgroundImage = `url("${coverImg}")`;
            trackImgEl.style.backgroundSize = 'cover';
            trackImgEl.style.backgroundPosition = 'center';
            
            // If image fails, use default
            const tempImg = new Image();
            tempImg.onerror = () => {
                trackImgEl.style.backgroundImage = 'url("assets/images/default-cover.jpg")';
            };
            tempImg.src = coverImg;
            
            // Update playlist context
            if (playlist.length > 0) {
                currentPlaylist = playlist;
                currentIndex = index;
            } else if (index === -1) {
                // No playlist provided — find this song in the full playlist or add it
                const existingIndex = currentPlaylist.findIndex(s => s.audio_url === url);
                if (existingIndex !== -1) {
                    currentIndex = existingIndex;
                } else {
                    currentPlaylist.push({ id: Date.now(), audio_url: url, title: title, image_url: img });
                    currentIndex = currentPlaylist.length - 1;
                }
            }

            savePlayerState();
            if (audio.paused) togglePlay();
            else audio.play();

            // Notify views (e.g. library sidebar) about song change
            if (typeof window.onSongChange === 'function') {
                const song = currentPlaylist[currentIndex];
                if (song) window.onSongChange(song, currentIndex);
            }
        }
        
        // Compatibility alias — matches (id, title, imgUrl, audioUrl) signature
        window.playSong = function(id, title, imgUrl, audioUrl) {
            if (!audioUrl || audioUrl.startsWith('task:')) {
                showToast('This song is still generating...', 'info');
                return;
            }
            if (!audioUrl.startsWith('http') && !audioUrl.startsWith('data:')) {
                audioUrl = window.location.origin + window.BASE_URL + '/' + audioUrl;
            }
            const playlist = window._libPlaylist || [];
            const index = playlist.findIndex(s => s.id === id);
            updatePlayer(audioUrl, title, imgUrl, playlist.length ? playlist : [{id, title, audio_url: audioUrl, image_url: imgUrl}], index >= 0 ? index : 0);
        };

        // Auto-play next song
        audio.onended = () => { playNext(); };
        audio.onerror = () => { showToast('Failed to load audio file', 'error'); };

        // Save position and update progress bar
        audio.ontimeupdate = () => {
            // Save state periodically
            if (Math.floor(audio.currentTime) % 5 === 0) savePlayerState();
            // Update progress bar
            const progress = (audio.currentTime / audio.duration) * 100;
            document.querySelector('.progress-fill').style.width = `${progress}%`;
            document.getElementById('current-time').innerText = formatTime(audio.currentTime);
            if (!isNaN(audio.duration)) {
                document.getElementById('duration-time').innerText = formatTime(audio.duration);
            }
        };

        function playNext() {
            if (currentPlaylist.length === 0) return;
            const nextIndex = currentIndex + 1;
            if (nextIndex < currentPlaylist.length) {
                const nextSong = currentPlaylist[nextIndex];
                updatePlayer(nextSong.audio_url, nextSong.title, nextSong.image_url, currentPlaylist, nextIndex);
            } else {
                // End of playlist — stop
                document.querySelector('.track-meta p').innerText = 'Finished';
                savePlayerState();
            }
        }

        function playPrevious() {
            // If song has played for more than 3 seconds, restart it
            if (audio.currentTime > 3) {
                audio.currentTime = 0;
                audio.play();
                return;
            }

            // Otherwise go to previous song in playlist
            if (currentIndex > 0) {
                const prevIndex = currentIndex - 1;
                const prevSong = currentPlaylist[prevIndex];
                updatePlayer(prevSong.audio_url, prevSong.title, prevSong.image_url, currentPlaylist, prevIndex);
            }
        }

        document.getElementById('next-btn').onclick = playNext;
        document.getElementById('prev-btn').onclick = playPrevious;

        // Volume Logic
        const volumeSlider = document.getElementById('volume-slider');
        const volumeIcon = document.getElementById('volume-icon');
        
        audio.volume = volumeSlider.value;
        
        volumeSlider.oninput = (e) => {
            const val = e.target.value;
            audio.volume = val;
            if (audioCtx.state === 'suspended') audioCtx.resume();
            if (val == 0) volumeIcon.className = 'fa-solid fa-volume-xmark';
            else if (val < 0.5) volumeIcon.className = 'fa-solid fa-volume-low';
            else volumeIcon.className = 'fa-solid fa-volume-high';
        };

        function togglePlay() {
            const btn = document.querySelector('.play-btn i');
            const trackStatus = document.querySelector('.track-meta p');
            if (audioCtx.state === 'suspended') audioCtx.resume();
            if (audio.paused) {
                audio.play();
                btn.classList.replace('fa-play', 'fa-pause');
                if (trackStatus) trackStatus.innerText = 'Playing now';
            } else {
                audio.pause();
                btn.classList.replace('fa-pause', 'fa-play');
                if (trackStatus) trackStatus.innerText = 'Paused';
                savePlayerState();
            }
        }

        document.querySelector('.play-btn').onclick = togglePlay;

        // Seeking Logic
        document.getElementById('progress-bar-container').onclick = (e) => {
            const rect = document.getElementById('progress-bar-container').getBoundingClientRect();
            const pos = (e.clientX - rect.left) / rect.width;
            if (!isNaN(audio.duration)) {
                audio.currentTime = pos * audio.duration;
            }
        };

        function formatTime(secs) {
            const mins = Math.floor(secs / 60);
            const s = Math.floor(secs % 60);
            return `${mins}:${s.toString().padStart(2, '0')}`;
        }

        // Initial load
        window.addEventListener('DOMContentLoaded', async () => {
            loadPage('home');
            checkAllPendingSongs();

            // Load all songs as the default playlist
            try {
                const res = await fetch('api/get_songs.php');
                const data = await res.json();
                if (data.success && data.songs) {
                    const completed = data.songs.filter(s => s.status === 'completed' && s.audio_url);
                    if (completed.length > 0) {
                        currentPlaylist = completed;
                    }
                }
            } catch(e) {}

            // Restore last playing state
            restorePlayerState();
            
            // Handle sharing deep-links
            const urlParams = new URLSearchParams(window.location.search);
            const sharedSong = urlParams.get('song');
            if(sharedSong) {
                // Fetch song data and play
                const res = await fetch(`api/get_song.php?id=${sharedSong}`);
                const data = await res.json();
                if(data.success) {
                    updatePlayer(data.song.audio_url, data.song.title, data.song.image_url);
                }
            }
        });
    </script>
    <style>
    @keyframes spin { to { transform: rotate(360deg); } }
    </style>
</body>
</html>
