<?php
require_once 'includes/auth.php';

$error = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = "Security validation failed.";
    } else {
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';
        
        $user = get_user_by_email($email);
        if ($user && password_verify($password, $user['password'])) {
            if ($user['is_banned']) {
                $error = "Your account has been blacklisted for rule violations.";
            } else {
                secure_login($user['id']);
                header("Location: index.php");
                exit;
            }
        } else {
            $error = "Invalid email or password.";
        }
    }
}
$csrf_token = generate_csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Wan2GP</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/main.css">
    <?php $stmt = $pdo->query("SELECT setting_value FROM site_settings WHERE setting_key = 'active_skin'"); $sk = $stmt->fetchColumn() ?: 'default'; if (file_exists(__DIR__ . '/skins/' . $sk . '/skin.css')): ?>
    <link rel="stylesheet" href="skins/<?php echo $sk; ?>/skin.css">
    <?php endif; ?>
    <style>
        body { display: flex; align-items: center; justify-content: center; height: 100vh; background: radial-gradient(circle at top right, #1a1a1a, #0a0a0a); }
        .auth-card { background: var(--bg-secondary); padding: 48px; border-radius: 32px; border: 1px solid var(--border-color); width: 100%; max-width: 420px; box-shadow: 0 40px 100px rgba(0,0,0,0.8); }
        .auth-card h1 { margin-bottom: 8px; font-weight: 800; font-size: 32px; }
        .auth-card p { color: var(--text-secondary); margin-bottom: 32px; }
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 10px; font-size: 14px; color: var(--text-secondary); }
        input { width: 100%; background: var(--bg-tertiary); border: 1px solid var(--border-color); padding: 14px 18px; border-radius: 16px; color: white; font-size: 16px; transition: all 0.3s; }
        input:focus { border-color: var(--accent-primary); outline: none; box-shadow: 0 0 0 4px rgba(236, 72, 153, 0.1); }
        .btn-auth { width: 100%; margin-top: 10px; font-size: 16px; padding: 16px; }
        .auth-footer { margin-top: 24px; text-align: center; color: var(--text-secondary); font-size: 14px; }
        .auth-footer a { color: var(--accent-primary); text-decoration: none; font-weight: 600; }
        .error-msg { background: rgba(248, 113, 113, 0.1); color: #f87171; padding: 12px; border-radius: 12px; margin-bottom: 20px; font-size: 14px; text-align: center; border: 1px solid rgba(248, 113, 113, 0.2); }
    </style>
</head>
<body>
    <div class="auth-card">
        <div class="logo">Wan2GP</div>
        <h1>Welcome back</h1>
        <p>Log in to continue creating music.</p>
        
        <?php if($error): ?> <div class="error-msg"><?php echo $error; ?></div> <?php endif; ?>

        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
            <div class="form-group">
                <label>Email Address</label>
                <input type="email" name="email" placeholder="name@example.com" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="••••••••" required>
            </div>
            <button type="submit" class="btn-primary btn-auth">Log In</button>
        </form>

        <div class="auth-footer">
            Don't have an account? <a href="register.php">Sign up</a>
        </div>
    </div>
</body>
</html>
