<?php
require_once 'includes/config.php';
require_once 'includes/generation_utils.php';

$task_id = 'db5a64ac-1116-4f9d-972a-db98a3679d22'; // Latest from DB

echo "Testing Query for Task: $task_id\n";
$result = query_acestep_task($task_id);
if(isset($result['error'])) {
    echo "ERROR: " . $result['error'] . "\n";
}
echo "Result: " . json_encode($result, JSON_PRETTY_PRINT) . "\n";
?>
