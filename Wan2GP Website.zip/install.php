<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

$config_file = 'includes/config.php';

// Check if already installed
if (file_exists($config_file)) {
    die("Application already installed. Please delete install.php for security.");
}

$status = "";
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db_host = $_POST['host'] ?? 'localhost';
    $db_user = $_POST['user'] ?? 'root';
    $db_pass = $_POST['pass'] ?? '';
    $db_name = $_POST['name'] ?? '';
    $base_url = $_POST['base_url'] ?? '/suno4';
    $base_url = rtrim(trim($base_url), '/');

    try {
        // Connect to MySQL server
        $pdo = new PDO("mysql:host=$db_host", $db_user, $db_pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Create database
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `$db_name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $pdo->exec("USE `$db_name` ");

        // Create Tables
        $sql = "
        CREATE TABLE IF NOT EXISTS site_settings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            setting_key VARCHAR(50) UNIQUE NOT NULL,
            setting_value TEXT,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB;

        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) UNIQUE NOT NULL,
            email VARCHAR(100) UNIQUE NOT NULL,
            avatar_url VARCHAR(255),
            password VARCHAR(255) NOT NULL,
            credits INT DEFAULT 50,
            role ENUM('user', 'admin') DEFAULT 'user',
            is_admin TINYINT(1) DEFAULT 0,
            is_banned TINYINT(1) DEFAULT 0,
            rules_accepted TINYINT(1) DEFAULT 0,
            last_credit_update TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB;

        CREATE TABLE IF NOT EXISTS songs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            task_id VARCHAR(100),
            title VARCHAR(255) NOT NULL,
            lyrics TEXT,
            tags VARCHAR(255),
            audio_url VARCHAR(255),
            image_url VARCHAR(255),
            duration INT,
            status ENUM('pending', 'completed', 'failed') DEFAULT 'pending',
            is_public TINYINT(1) DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB;

        CREATE TABLE IF NOT EXISTS sessions (
            id VARCHAR(128) PRIMARY KEY,
            user_id INT NOT NULL,
            data TEXT,
            last_activity INT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB;

        INSERT IGNORE INTO site_settings (setting_key, setting_value) VALUES ('site_rules', '1. Be respectful to others.\\n2. Do not generate offensive content.\\n3. One account per person.\\n4. Enjoy the music!');
        INSERT IGNORE INTO site_settings (setting_key, setting_value) VALUES ('active_skin', 'default');
        ";

        $pdo->exec($sql);

        // Generate Config File
        if (!is_dir('includes')) {
            mkdir('includes', 0755, true);
        }

        $config_content = "<?php
// Secure Configuration File
define('DB_HOST', '$db_host');
define('DB_NAME', '$db_name');
define('DB_USER', '$db_user');
define('DB_PASS', '$db_pass');
define('BASE_URL', '$base_url');

// Security Settings
define('SESSION_SECURE', false); // Set to true if using HTTPS
define('CSRF_SECRET', '" . bin2hex(random_bytes(32)) . "');

try {
    \$pdo = new PDO(\"mysql:host=\" . DB_HOST . \";dbname=\" . DB_NAME, DB_USER, DB_PASS);
    \$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    \$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException \$e) {
    die(\"Database Connection Failed: \" . \$e->getMessage());
}
";

        file_put_contents($config_file, $config_content);
        $status = "Installation Successful! You can now <a href='index.php'>Go to Home</a>. <strong>IMPORTANT: Delete install.php now!</strong>";

    } catch (PDOException $e) {
        $error = "Error: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Suno Clone - Secure Installer</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;800&display=swap" rel="stylesheet">
    <style>
        body { background: #0a0a0a; color: white; font-family: 'Outfit', sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
        .card { background: #121212; padding: 40px; border-radius: 24px; border: 1px solid rgba(255,255,255,0.1); width: 100%; max-width: 450px; box-shadow: 0 20px 40px rgba(0,0,0,0.5); }
        h1 { margin-bottom: 24px; font-weight: 800; text-align: center; background: linear-gradient(to right, #ec4899, #8b5cf6); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
        .form-group { margin-bottom: 16px; }
        label { display: block; margin-bottom: 8px; color: #a0a0a0; font-size: 14px; }
        input { width: 100%; background: #1a1a1a; border: 1px solid rgba(255,255,255,0.1); padding: 12px; border-radius: 12px; color: white; font-size: 16px; outline: none; }
        input:focus { border-color: #ec4899; }
        .btn { width: 100%; background: linear-gradient(135deg, #ec4899, #8b5cf6); border: none; padding: 14px; border-radius: 12px; color: white; font-weight: 600; cursor: pointer; margin-top: 10px; }
        .status { color: #4ade80; text-align: center; margin-top: 20px; }
        .error { color: #f87171; text-align: center; margin-top: 20px; }
    </style>
</head>
<body>
    <div class="card">
        <h1>Wan2GP Setup</h1>
        <form method="POST">
            <div class="form-group">
                <label>Database Host</label>
                <input type="text" name="host" value="localhost" required placeholder="Database Host">
            </div>
            <div class="form-group">
                <label>Database Name</label>
                <input type="text" name="name" value="" required placeholder="Database Name">
            </div>
            <div class="form-group">
                <label>Database User</label>
                <input type="text" name="user" value="root" required placeholder="Database User">
            </div>
            <div class="form-group">
                <label>Database Password</label>
                <input type="password" name="pass" value="" placeholder="Database Password">
            </div>
            <div class="form-group">
                <label>Base URL (path to installation, e.g. /your folder... )</label>
                <input type="text" name="base_url" value="" required placeholder="Base URL">
            </div>
            <button type="submit" class="btn">Install Platform</button>
        </form>
        <?php if($status): ?> <div class="status"><?php echo $status; ?></div> <?php endif; ?>
        <?php if($error): ?> <div class="error"><?php echo $error; ?></div> <?php endif; ?>
    </div>
</body>
</html>
