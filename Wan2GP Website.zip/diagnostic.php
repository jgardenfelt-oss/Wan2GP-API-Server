<?php
/**
 * WanGP API Diagnostic Tool
 * Tests the local API server on port 8001
 */

$base_url = 'http://127.0.0.1:8001';

echo "=== WanGP API Diagnostic ===\n\n";

// 1. Test server root
echo "1. Testing server root...\n";
$ch = curl_init($base_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$res = curl_exec($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
echo "   Code: $code\n";
echo "   Response: $res\n\n";

// 2. List available models
echo "2. Listing models...\n";
$ch = curl_init($base_url . '/models');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$res = curl_exec($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
echo "   Code: $code\n";
$models = json_decode($res, true);
if (isset($models['models'])) {
    foreach ($models['models'] as $m) {
        $avail = $m['availability']['available'] ?? false;
        $status = $avail ? 'AVAILABLE' : 'MISSING';
        echo "   - {$m['model_type']}: {$m['name']} [$status]\n";
    }
}
echo "\n";

// 3. Test create_task
echo "3. Testing create_task...\n";
$payload = json_encode([
    'prompt' => 'pop, male vocals\n[Verse]\nTest lyrics here',
    'model_type' => 'ace_step_v1_5_turbo_lm_1_7b'
]);
$ch = curl_init($base_url . '/create_task');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
$res = curl_exec($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
echo "   Code: $code\n";
echo "   Response: $res\n";
$task = json_decode($res, true);
$task_id = $task['task_id'] ?? null;
echo "\n";

// 4. Test task_status
if ($task_id) {
    echo "4. Testing task_status for $task_id...\n";
    $ch = curl_init($base_url . '/task_status/' . $task_id);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $res = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    echo "   Code: $code\n";
    echo "   Response: $res\n\n";
}

// 5. Test list_tasks
echo "5. Testing list_tasks...\n";
$ch = curl_init($base_url . '/list_tasks');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$res = curl_exec($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
echo "   Code: $code\n";
echo "   Response: $res\n\n";

echo "=== Done ===\n";
?>
