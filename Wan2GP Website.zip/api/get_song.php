<?php
/**
 * Public/Private Song Data Fetcher
 */
require_once '../includes/auth.php';

header('Content-Type: application/json');

$song_id = $_GET['id'] ?? null;
if (!$song_id) {
    echo json_encode(['error' => 'ID required']);
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT title, audio_url, image_url FROM songs WHERE id = ?");
    $stmt->execute([$song_id]);
    $song = $stmt->fetch();
    
    if ($song) {
        echo json_encode(['success' => true, 'song' => $song]);
    } else {
        echo json_encode(['error' => 'Not found']);
    }
} catch (Exception $e) {
    echo json_encode(['error' => 'Database error']);
}
?>
