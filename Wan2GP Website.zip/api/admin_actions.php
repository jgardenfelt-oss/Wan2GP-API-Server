<?php
require_once '../includes/auth.php';

$user = get_current_user_data();
if (!$user || !$user['is_admin']) {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$action = $data['action'] ?? '';

try {
    switch ($action) {
        case 'add_credits':
            $target_user_id = $data['user_id'];
            $amount = $data['amount'];
            $stmt = $pdo->prepare("UPDATE users SET credits = credits + ? WHERE id = ?");
            $stmt->execute([$amount, $target_user_id]);
            echo json_encode(['success' => true]);
            break;

        case 'update_rules':
            $rules = $data['rules'];
            $stmt = $pdo->prepare("UPDATE site_settings SET setting_value = ? WHERE setting_key = 'site_rules'");
            $stmt->execute([$rules]);
            echo json_encode(['success' => true]);
            break;

        case 'delete_song_admin':
            $song_id = $data['song_id'];
            $stmt = $pdo->prepare("DELETE FROM songs WHERE id = ?");
            $stmt->execute([$song_id]);
            echo json_encode(['success' => true]);
            break;

        case 'toggle_ban':
            $target_user_id = $data['user_id'];
            $stmt = $pdo->prepare("UPDATE users SET is_banned = 1 - is_banned WHERE id = ?");
            $stmt->execute([$target_user_id]);
            echo json_encode(['success' => true]);
            break;

        case 'toggle_admin':
            $target_user_id = $data['user_id'];
            // Prevent admin from revoking their own rights if they are the only admin? 
            // Or just allow it, they should know what they are doing.
            $stmt = $pdo->prepare("UPDATE users SET is_admin = 1 - is_admin, role = IF(is_admin = 0, 'admin', 'user') WHERE id = ?");
            $stmt->execute([$target_user_id]);
            echo json_encode(['success' => true]);
            break;

        case 'set_skin':
            $skin = $data['skin'] ?? 'default';
            // Sanitize: only allow alphanumeric and underscore
            $skin = preg_replace('/[^a-zA-Z0-9_-]/', '', $skin);
            // Verify the skin folder and CSS exist
            $skinPath = __DIR__ . '/../skins/' . $skin . '/skin.css';
            if (!file_exists($skinPath)) {
                echo json_encode(['error' => 'Skin not found']);
                break;
            }
            $stmt = $pdo->prepare("UPDATE site_settings SET setting_value = ? WHERE setting_key = 'active_skin'");
            $stmt->execute([$skin]);
            echo json_encode(['success' => true]);
            break;

        default:
            echo json_encode(['error' => 'Invalid action']);
    }
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>
