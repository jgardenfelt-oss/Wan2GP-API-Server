<?php
require_once 'includes/config.php';
$stmt = $pdo->query("SELECT setting_value FROM site_settings WHERE setting_key = 'site_rules'");
$rules = $stmt->fetchColumn() ?: 'Please follow the site rules.';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Site Rules - Suno Clone</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/main.css">
    <?php $stmt = $pdo->query("SELECT setting_value FROM site_settings WHERE setting_key = 'active_skin'"); $sk = $stmt->fetchColumn() ?: 'default'; if (file_exists(__DIR__ . '/skins/' . $sk . '/skin.css')): ?>
    <link rel="stylesheet" href="skins/<?php echo $sk; ?>/skin.css">
    <?php endif; ?>
    <style>
        body { background: #0a0a0a; color: white; padding: 40px; display: flex; justify-content: center; }
        .rules-card { background: var(--bg-secondary); padding: 48px; border-radius: 32px; border: 1px solid var(--border-color); width: 100%; max-width: 600px; }
        h1 { font-weight: 800; margin-bottom: 24px; color: var(--accent-primary); }
        .content { line-height: 1.8; color: var(--text-secondary); white-space: pre-wrap; }
        .back-link { margin-top: 40px; display: inline-block; color: white; text-decoration: none; font-size: 14px; opacity: 0.6; }
        .back-link:hover { opacity: 1; }
    </style>
</head>
<body>
    <div class="rules-card">
        <h1>Site Rules & Terms</h1>
        <div class="content custom-scrollbar" style="white-space: pre-wrap; max-height: 60vh; overflow-y: auto; background: var(--bg-tertiary); padding: 32px; border-radius: 24px; margin-bottom: 24px;"><?php echo htmlspecialchars($rules); ?></div>
        <a href="register.php" class="back-link">← Go Back to Registration</a>
    </div>
    <style>
    .custom-scrollbar::-webkit-scrollbar { width: 8px; }
    .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
    .custom-scrollbar::-webkit-scrollbar-thumb { background: var(--bg-secondary); border: 2px solid var(--bg-tertiary); border-radius: 10px; }
    </style>
</body>
</html>
