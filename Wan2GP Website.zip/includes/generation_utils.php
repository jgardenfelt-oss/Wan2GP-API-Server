<?php
/**
 * WanGP / ACE-Step 1.5 Integration Utilities
 * Uses the WanGP API server running on localhost:8001
 */

define('API_BASE_URL', 'http://127.0.0.1:8001');
define('ACE_STEP_MODEL', 'ace_step_v1_5_turbo_lm_1_7b');

/**
 * Duration is now auto-determined by the LM (model_mode=4).
 * This function is kept for backward compatibility but is no longer used.
 */

/**
 * Make a request to the WanGP API
 */
function wgp_request($endpoint, $method = 'GET', $payload = null) {
    $url = API_BASE_URL . $endpoint;
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        if ($payload !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        }
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    }
    
    $response = curl_exec($ch);
    $error = curl_error($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($error) return ['error' => "API Connection Error: $error"];
    if ($http_code >= 400) return ['error' => "API returned HTTP $http_code: $response"];
    
    $result = json_decode($response, true);
    if ($result === null) return ['error' => "Invalid JSON response: $response"];
    
    return $result;
}

/**
 * Submit task to WanGP API (POST /create_task)
 * Uses ACE-Step 1.5 model for music generation
 * 
 * WanGP ACE-Step field mapping:
 *   prompt       = lyrics (with section tags like [Verse], [Chorus])
 *   alt_prompt   = style/tags description (e.g. "pop, male vocals, upbeat")
 *   model_mode   = 4 (LM auto-determines best duration from lyrics & caption)
 */
function submit_acestep_task($describe_prompt, $style_description, $title, $lyrics) {
    // alt_prompt = style/tags description for WanGP
    $alt_prompt = !empty($style_description) ? $style_description : ($describe_prompt ?: 'pop, vocal');
    
    $payload = [
        "prompt" => $lyrics,
        "alt_prompt" => $alt_prompt,
        "model_type" => ACE_STEP_MODEL,
        "model_mode" => 4,
        "num_inference_steps" => 8
    ];

    $result = wgp_request('/create_task', 'POST', $payload);
    
    if (isset($result['error'])) return $result;
    if (!isset($result['task_id'])) return ['error' => "Failed to get task_id. Response: " . json_encode($result)];

    return [
        'success' => true,
        'task_id' => $result['task_id']
    ];
}

/**
 * Query task status from WanGP API (GET /task_status/{task_id})
 * When completed, returns a download URL via /get_result/{task_id}
 */
function query_acestep_task($task_id) {
    $result = wgp_request('/task_status/' . $task_id, 'GET');
    
    if (isset($result['error']) && !empty($result['error'])) return $result;
    
    $status = $result['status'] ?? '';
    
    if ($status === 'completed') {
        // WanGP returns local Windows paths in output_files, which can't be fetched via HTTP.
        // Instead, use /get_result/{task_id} which returns the actual file content.
        $audio_url = API_BASE_URL . '/get_result/' . $task_id;
        
        return [
            'completed' => true,
            'audio_url' => $audio_url,
            'image_url' => '',
            'raw_data' => $result
        ];
    } elseif ($status === 'failed') {
        return ['error' => "Generation failed: " . ($result['error'] ?? 'Unknown error'), 'raw_data' => $result];
    }
    
    // Still running (queued, running, etc.)
    return ['completed' => false, 'progress' => $result['progress'] ?? 0, 'raw_data' => $result];
}

/**
 * Get the Google API key from database
 */
function get_google_api_key() {
    global $pdo;
    $stmt = $pdo->query("SELECT setting_value FROM site_settings WHERE setting_key = 'google_api_key'");
    return $stmt->fetchColumn() ?: '';
}

/**
 * Generate full song with Gemini: lyrics + production style
 */
function generate_full_song_with_gemini($description, $title = '') {
    $api_key = get_google_api_key();
    if (empty($api_key)) {
        return ['error' => 'No Google API key configured'];
    }

    $prompt = "You are a professional music producer and songwriter. A user wants you to create a full song from a brief description.\n\n";
    if ($title) {
        $prompt .= "Song title: $title\n";
    }
    $prompt .= "User description: $description\n\n";
    $prompt .= "Create a complete song package. Respond in this EXACT format:\n\n";
    $prompt .= "[STYLE]\n";
    $prompt .= "A detailed music production description for the AI music generator. Include: genre, tempo (BPM range), mood, key instruments, vocal style (male/female, soft/powerful/raspy), energy level, and any specific production elements. Be descriptive and specific. Example: \"indie folk, slow tempo 85 BPM, warm acoustic guitar, soft female vocals, gentle cello, intimate and melancholic mood, finger-picked guitar patterns, atmospheric reverb\"\n\n";
    $prompt .= "[LYRICS]\n";
    $prompt .= "Complete song lyrics with section tags like [Verse 1], [Chorus], [Verse 2], [Bridge], [Outro]. Make the chorus catchy and memorable. Write at least 2 verses and a chorus. Lyrics should match the style and mood described above.\n\n";
    $prompt .= "IMPORTANT: Use the exact [STYLE] and [LYRICS] tags. Do not add any other text outside these sections.";

    $url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" . $api_key;

    $payload = [
        "contents" => [
            [
                "parts" => [
                    ["text" => $prompt]
                ]
            ]
        ],
        "generationConfig" => [
            "temperature" => 0.9,
            "maxOutputTokens" => 4096
        ]
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_TIMEOUT, 90);

    $response = curl_exec($ch);
    $error = curl_error($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($error) {
        return ['error' => "Gemini API connection error: $error"];
    }
    if ($http_code >= 400) {
        return ['error' => "Gemini API returned HTTP $http_code: $response"];
    }

    $result = json_decode($response, true);
    if ($result === null) {
        return ['error' => "Invalid response from Gemini API"];
    }

    if (isset($result['error'])) {
        return ['error' => "Gemini API error: " . ($result['error']['message'] ?? json_encode($result['error']))];
    }

    $text = $result['candidates'][0]['content']['parts'][0]['text'] ?? '';
    if (empty($text)) {
        return ['error' => "Gemini returned empty response"];
    }

    $text = trim($text);
    $text = preg_replace('/^```[a-z]*\n?/i', '', $text);
    $text = preg_replace('/\n?```$/', '', $text);
    $text = trim($text);

    $style = '';
    $lyrics = '';

    if (preg_match('/\[STYLE\]\s*\n(.+?)(?=\n\[LYRICS\])/s', $text, $m)) {
        $style = trim($m[1]);
    }
    if (preg_match('/\[LYRICS\]\s*\n(.+)/s', $text, $m)) {
        $lyrics = trim($m[1]);
    }

    if (empty($lyrics)) {
        return ['error' => "Gemini did not return lyrics"];
    }
    if (empty($style)) {
        $style = $description;
    }

    return ['success' => true, 'lyrics' => $lyrics, 'style' => $style];
}
?>
