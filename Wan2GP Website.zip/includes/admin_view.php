<?php
require_once __DIR__ . '/auth.php';

$user = get_current_user_data();
if (!$user || !$user['is_admin']) {
    echo '<div style="padding: 24px;">Unauthorized access.</div>';
    exit;
}

// Fetch all users
$stmt = $pdo->query("SELECT id, username, email, credits, is_admin, is_banned FROM users ORDER BY username ASC");
$users = $stmt->fetchAll();

// Fetch all songs
$stmt = $pdo->query("SELECT s.*, u.username FROM songs s JOIN users u ON s.user_id = u.id ORDER BY s.created_at DESC");
$all_songs = $stmt->fetchAll();

// Fetch current rules
$stmt = $pdo->query("SELECT setting_value FROM site_settings WHERE setting_key = 'site_rules'");
$rules = $stmt->fetchColumn();

// Fetch active skin
$stmt = $pdo->query("SELECT setting_value FROM site_settings WHERE setting_key = 'active_skin'");
$currentSkin = $stmt->fetchColumn() ?: 'default';

// Fetch Google API key
$stmt = $pdo->query("SELECT setting_value FROM site_settings WHERE setting_key = 'google_api_key'");
$googleApiKey = $stmt->fetchColumn() ?: '';

// Scan skins folder
$skins = [];
if (is_dir(__DIR__ . '/../skins')) {
    foreach (scandir(__DIR__ . '/../skins') as $dir) {
        if ($dir === '.' || $dir === '..') continue;
        if (is_dir(__DIR__ . '/../skins/' . $dir) && file_exists(__DIR__ . '/../skins/' . $dir . '/skin.css')) {
            $skins[] = $dir;
        }
    }
}
?>
<div class="admin-container" style="padding: 24px 0; display: flex; flex-direction: column; gap: 32px;">
    
    <!-- Site Rules Management -->
    <section style="background: var(--bg-secondary); padding: 24px; border-radius: 24px; border: 1px solid var(--border-color);">
        <h2 style="font-size: 18px; margin-bottom: 16px;">Site Rules & Terms</h2>
        <textarea id="admin-rules" style="width: 100%; height: 150px; background: var(--bg-tertiary); border: 1px solid var(--border-color); border-radius: 12px; padding: 16px; color: white; margin-bottom: 16px;"><?php echo htmlspecialchars($rules); ?></textarea>
        <button class="btn-primary" onclick="updateRules()">Update Rules</button>
    </section>

    <!-- Skin Management -->
    <section style="background: var(--bg-secondary); padding: 24px; border-radius: 24px; border: 1px solid var(--border-color);">
        <h2 style="font-size: 18px; margin-bottom: 16px;">Site Skin / Theme</h2>
        <p style="color: var(--text-secondary); font-size: 13px; margin-bottom: 16px;">Choose a skin to change the site's color scheme. Changes apply to all users.</p>
        <div id="skin-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 16px;">
            <?php foreach ($skins as $skin): ?>
                <?php
                    $skinData = file_get_contents(__DIR__ . '/../skins/' . $skin . '/skin.css');
                    preg_match('/--accent-primary:\s*([^;]+)/', $skinData, $m1);
                    preg_match('/--accent-secondary:\s*([^;]+)/', $skinData, $m2);
                    preg_match('/--bg-main:\s*([^;]+)/', $skinData, $m3);
                    $accent1 = $m1[1] ?? '#ec4899';
                    $accent2 = $m2[1] ?? '#8b5cf6';
                    $bgMain = $m3[1] ?? '#0a0a0a';
                ?>
                <div class="skin-card" onclick="applySkin('<?php echo $skin; ?>')" style="background: <?php echo $bgMain; ?>; border: 2px solid <?php echo $currentSkin === $skin ? $accent1 : 'transparent'; ?>; border-radius: 16px; padding: 16px; cursor: pointer; transition: all 0.2s; text-align: center;" onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                    <div style="display: flex; gap: 6px; justify-content: center; margin-bottom: 10px;">
                        <div style="width: 24px; height: 24px; border-radius: 50%; background: <?php echo $accent1; ?>;"></div>
                        <div style="width: 24px; height: 24px; border-radius: 50%; background: <?php echo $accent2; ?>;"></div>
                    </div>
                    <h4 style="font-size: 13px; text-transform: capitalize; color: <?php echo $accent1; ?>;"><?php echo $skin; ?></h4>
                    <?php if ($currentSkin === $skin): ?>
                        <span style="font-size: 10px; color: var(--text-secondary); display: block; margin-top: 4px;">Active</span>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- Google API Key -->
    <section style="background: var(--bg-secondary); padding: 24px; border-radius: 24px; border: 1px solid var(--border-color);">
        <h2 style="font-size: 18px; margin-bottom: 16px;">Google API Key</h2>
        <p style="color: var(--text-secondary); font-size: 13px; margin-bottom: 16px;">Enter your Google API key. Get one at <a href="https://console.cloud.google.com/apis/credentials" target="_blank" rel="noopener" style="color: var(--accent-primary); text-decoration: none; font-weight: 600;">Google Cloud Console</a>.</p>
        <div style="display: flex; gap: 12px; align-items: center;">
            <input type="password" id="admin-google-api-key" value="<?php echo htmlspecialchars($googleApiKey); ?>" placeholder="Enter Google API key..." style="flex: 1; background: var(--bg-tertiary); border: 1px solid var(--border-color); border-radius: 12px; padding: 12px 16px; color: white; font-size: 14px; outline: none;">
            <button class="btn-primary" onclick="updateGoogleApiKey()">Save Key</button>
        </div>
    </section>

    <!-- User Management -->
    <section style="background: var(--bg-secondary); padding: 24px; border-radius: 24px; border: 1px solid var(--border-color);">
        <h2 style="font-size: 18px; margin-bottom: 16px;">User Management</h2>
        <div style="overflow-x: auto;">
            <table style="width: 100%; border-collapse: collapse; text-align: left;">
                <thead>
                    <tr style="color: var(--text-secondary); font-size: 14px; border-bottom: 1px solid var(--border-color);">
                        <th style="padding: 12px;">User</th>
                        <th style="padding: 12px;">Email</th>
                        <th style="padding: 12px;">Credits</th>
                        <th style="padding: 12px;">Status</th>
                        <th style="padding: 12px;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $u): ?>
                    <tr style="border-bottom: 1px solid var(--border-color); font-size: 14px;">
                        <td style="padding: 12px;"><?php echo htmlspecialchars($u['username']); ?></td>
                        <td style="padding: 12px;"><?php echo htmlspecialchars($u['email']); ?></td>
                        <td style="padding: 12px;"><?php echo $u['credits']; ?></td>
                        <td style="padding: 12px;">
                            <span style="padding: 4px 8px; border-radius: 6px; font-size: 11px; background: <?php echo $u['is_admin'] ? 'rgba(236, 72, 153, 0.2)' : 'rgba(255,255,255,0.05)'; ?>; color: <?php echo $u['is_admin'] ? 'var(--accent-primary)' : 'var(--text-secondary)'; ?>;">
                                <?php echo $u['is_admin'] ? 'ADMIN' : 'USER'; ?>
                            </span>
                        </td>
                        <td style="padding: 12px; display: flex; gap: 8px; align-items: center;">
                            <input type="number" id="credits-<?php echo $u['id']; ?>" placeholder="Qty" style="width: 60px; background: var(--bg-tertiary); border: 1px solid var(--border-color); border-radius: 8px; padding: 4px 8px; color: white;">
                            <button class="btn-primary" style="padding: 4px 10px; font-size: 11px;" onclick="addCredits(<?php echo $u['id']; ?>)">Add</button>
                            
                            <button class="btn-secondary" style="padding: 4px 10px; font-size: 11px; background: var(--bg-tertiary); border-color: var(--accent-primary); color: var(--accent-primary);" onclick="toggleAdmin(<?php echo $u['id']; ?>)">
                                <?php echo $u['is_admin'] ? 'Revoke Admin' : 'Make Admin'; ?>
                            </button>

                            <button class="btn-secondary" style="padding: 4px 10px; font-size: 11px; background: <?php echo $u['is_banned'] ? '#10b981' : '#ef4444'; ?>; color: white;" onclick="toggleBan(<?php echo $u['id']; ?>)">
                                <?php echo $u['is_banned'] ? 'Unban' : 'Ban'; ?>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>

    <!-- Song Moderation -->
    <section style="background: var(--bg-secondary); padding: 24px; border-radius: 24px; border: 1px solid var(--border-color);">
        <h2 style="font-size: 18px; margin-bottom: 16px;">Global Library (All User Songs)</h2>
        <div style="overflow-x: auto;">
            <table style="width: 100%; border-collapse: collapse; text-align: left;">
                <thead>
                    <tr style="color: var(--text-secondary); font-size: 14px; border-bottom: 1px solid var(--border-color);">
                        <th style="padding: 12px;">User</th>
                        <th style="padding: 12px;">Song Title</th>
                        <th style="padding: 12px;">Status</th>
                        <th style="padding: 12px;">Created</th>
                        <th style="padding: 12px;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($all_songs as $s): ?>
                    <tr style="border-bottom: 1px solid var(--border-color); font-size: 14px;">
                        <td style="padding: 12px;"><?php echo htmlspecialchars($s['username']); ?></td>
                        <td style="padding: 12px;"><?php echo htmlspecialchars($s['title']); ?></td>
                        <td style="padding: 12px;"><span style="color: <?php echo $s['status'] === 'completed' ? '#10b981' : '#f59e0b'; ?>"><?php echo $s['status']; ?></span></td>
                        <td style="padding: 12px;"><?php echo date('Y-m-d', strtotime($s['created_at'])); ?></td>
                        <td style="padding: 12px;">
                            <button onclick="deleteSongAdmin(<?php echo $s['id']; ?>)" style="color: #f87171; background: none; border: none; cursor: pointer;"><i class="fa-solid fa-trash"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
</div>

<script>
async function addCredits(userId) {
    const amount = document.getElementById(`credits-${userId}`).value;
    if(!amount) return;
    
    const res = await fetch('api/admin_actions.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'add_credits', user_id: userId, amount: parseInt(amount) })
    });
    const data = await res.json();
    if(data.success) {
        alert('Credits added!');
        loadPage('admin');
    }
}

async function toggleAdmin(userId) {
    if(!confirm('Change administrator rights for this user?')) return;
    const res = await fetch('api/admin_actions.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'toggle_admin', user_id: userId })
    });
    const data = await res.json();
    if(data.success) loadPage('admin');
}

async function toggleBan(userId) {
    if(!confirm('Change ban status for this user?')) return;
    const res = await fetch('api/admin_actions.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'toggle_ban', user_id: userId })
    });
    const data = await res.json();
    if(data.success) loadPage('admin');
}

async function updateRules() {
    const rules = document.getElementById('admin-rules').value;
    const res = await fetch('api/admin_actions.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'update_rules', rules: rules })
    });
    const data = await res.json();
    if(data.success) alert('Rules updated!');
}

async function applySkin(skin) {
    const res = await fetch('api/admin_actions.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'set_skin', skin: skin })
    });
    const data = await res.json();
    if(data.success) {
        // Reload the skin CSS without full page reload
        const link = document.getElementById('skin-css');
        if (link) link.href = 'skins/' + skin + '/skin.css';
        loadPage('admin');
    }
}

async function deleteSongAdmin(songId) {
    if(!confirm('Delete this song permanently?')) return;
    const res = await fetch('api/admin_actions.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'delete_song_admin', song_id: songId })
    });
    const data = await res.json();
    if(data.success) loadPage('admin');
}

async function updateGoogleApiKey() {
    const key = document.getElementById('admin-google-api-key').value.trim();
    const res = await fetch('api/admin_actions.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'update_google_api_key', key: key })
    });
    const data = await res.json();
    if(data.success) alert('Google API Key saved!');
}
</script>
