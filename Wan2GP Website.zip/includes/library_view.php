<?php
require_once __DIR__ . '/auth.php';
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM songs WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([$user_id]);
$allSongs = $stmt->fetchAll();

$liked = $pdo->prepare("SELECT s.* FROM likes l JOIN songs s ON l.song_id = s.id WHERE l.user_id = ? ORDER BY l.created_at DESC");
$liked->execute([$user_id]);
$likedSongs = $liked->fetchAll();
?>
<div class="library-tabs" style="display: flex; gap: 16px; margin-bottom: 24px;">
    <button class="library-tab active" data-tab="mine" onclick="switchLibTab('mine')" style="padding: 10px 20px; border-radius: 12px; border: none; background: var(--bg-tertiary); color: var(--text-primary); font-weight: 600; cursor: pointer; font-family: var(--font-main);">My Songs</button>
    <button class="library-tab" data-tab="liked" onclick="switchLibTab('liked')" style="padding: 10px 20px; border-radius: 12px; border: none; background: transparent; color: var(--text-secondary); font-weight: 600; cursor: pointer; font-family: var(--font-main);">Liked</button>
</div>

<div style="display: flex; gap: 24px;">
    <!-- Song List -->
    <div style="flex: 1; min-width: 0;">
        <div id="lib-mine">
            <?php if (empty($allSongs)): ?>
                <div style="text-align: center; padding: 80px 0; color: var(--text-secondary);"><i class="fa-solid fa-music" style="font-size: 48px; margin-bottom: 16px; display: block;"></i><p>No songs yet.</p></div>
            <?php else: ?>
                <div id="lib-mine-list">
                <?php foreach ($allSongs as $index => $song): ?>
                    <?php $cover = $song['image_url'] ?: 'https://picsum.photos/seed/'.$song['id'].'/400/400'; ?>
                    <div class="song-row" data-song-id="<?php echo $song['id']; ?>" onclick="showSongDetails(<?php echo htmlspecialchars(json_encode($song)); ?>, <?php echo $index; ?>)">
                        <div class="song-row-img" style="background-image: url('<?php echo $cover; ?>');"></div>
                        <div class="song-row-info">
                            <div class="song-row-title"><?php echo htmlspecialchars($song['title']); ?></div>
                            <div class="song-row-meta"><?php echo $song['status'] === 'completed' ? 'Complete' : 'Generating'; ?> • <?php echo date('M d', strtotime($song['created_at'])); ?></div>
                        </div>
                        <div class="song-row-actions">
                            <?php if ($song['status'] === 'completed'): ?>
                                <button class="icon-btn" onclick="event.stopPropagation(); playSong(<?php echo $song['id']; ?>, '<?php echo addslashes($song['title']); ?>', '<?php echo $cover; ?>', '<?php echo $song['audio_url']; ?>')"><i class="fa-solid fa-play"></i></button>
                                <button class="action-btn" onclick="event.stopPropagation(); shareSong(<?php echo $song['id']; ?>)" title="Share" style="<?php echo $song['is_public'] ? 'color: var(--accent-primary);' : ''; ?>"><i class="fa-solid fa-share-nodes"></i></button>
                                <button class="action-btn" onclick="event.stopPropagation(); deleteSong(<?php echo $song['id']; ?>)" title="Delete"><i class="fa-solid fa-trash"></i></button>
                            <?php elseif ($song['status'] === 'pending'): ?>
                                <span class="song-elapsed">0s</span>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <div id="lib-liked" style="display: none;">
            <?php if (empty($likedSongs)): ?>
                <div style="text-align: center; padding: 80px 0; color: var(--text-secondary);"><i class="fa-solid fa-heart" style="font-size: 48px; margin-bottom: 16px; display: block;"></i><p>No liked songs yet.</p></div>
            <?php else: ?>
                <div id="lib-liked-list">
                <?php foreach ($likedSongs as $index => $song): ?>
                    <?php $lcover = $song['image_url'] ?: 'https://picsum.photos/seed/'.$song['id'].'/400/400'; ?>
                    <div class="song-row">
                        <div class="song-row-img" style="background-image: url('<?php echo $lcover; ?>');"></div>
                        <div class="song-row-info">
                            <div class="song-row-title"><?php echo htmlspecialchars($song['title']); ?></div>
                            <div class="song-row-meta"><?php echo $song['status'] === 'completed' ? 'Complete' : 'Generating'; ?></div>
                        </div>
                        <div class="song-row-actions">
                            <?php if ($song['status'] === 'completed'): ?>
                                <button class="icon-btn" onclick="playSong(<?php echo $song['id']; ?>, '<?php echo addslashes($song['title']); ?>', '<?php echo $lcover; ?>', '<?php echo $song['audio_url']; ?>')"><i class="fa-solid fa-play"></i></button>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Right Sidebar: Song Details -->
    <div id="song-details" style="width: 320px; flex-shrink: 0; background: var(--bg-secondary); border-radius: 20px; border: 1px solid var(--border-color); overflow-y: auto; display: none;">
        <div id="details-empty" style="text-align: center; padding: 80px 20px; color: var(--text-secondary);">
            <i class="fa-solid fa-music" style="font-size: 48px; margin-bottom: 20px; opacity: 0.15;"></i>
            <p style="font-size: 15px;">Select a song to view details</p>
        </div>
        <div id="details-content" style="display: none; flex-direction: column; padding: 24px;">
            <div style="width: 100%; aspect-ratio: 1; border-radius: 16px; overflow: hidden; margin-bottom: 20px;">
                <img id="detail-image" src="" style="width: 100%; height: 100%; object-fit: cover;">
            </div>
            <h2 id="detail-title" style="font-size: 20px; font-weight: 700; margin-bottom: 4px; line-height: 1.3;"></h2>
            <p id="detail-tags" style="color: var(--accent-primary); font-size: 13px; font-weight: 500; margin-bottom: 16px;"></p>
            <div style="display: flex; gap: 10px; margin-bottom: 20px;">
                <button id="detail-play-btn" class="btn-primary" style="flex: 1; padding: 12px; border-radius: 12px; font-weight: 600; background: var(--accent-primary); color: white; border: none; cursor: pointer;">
                    <i class="fa-solid fa-play"></i> Play
                </button>
                <a id="detail-download-btn" href="#" style="padding: 12px 16px; border-radius: 12px; text-decoration: none; display: flex; align-items: center; justify-content: center; background: var(--bg-tertiary); color: white; border: 1px solid var(--border-color); transition: background 0.2s;" onmouseover="this.style.background='rgba(255,255,255,0.1)'" onmouseout="this.style.background='var(--bg-tertiary)'">
                    <i class="fa-solid fa-download"></i>
                </a>
                <button id="detail-share-btn" class="action-btn" style="padding: 12px;" onclick="shareSong(currentDetailSongId)">
                    <i class="fa-solid fa-share-nodes"></i>
                </button>
            </div>
            <div style="background: var(--bg-tertiary); border-radius: 12px; padding: 16px; flex: 1; overflow-y: auto;">
                <h4 style="font-size: 11px; text-transform: uppercase; letter-spacing: 1.5px; color: var(--text-secondary); margin-bottom: 12px; font-weight: 600;">Lyrics</h4>
                <div id="detail-lyrics" style="font-size: 14px; line-height: 1.8; color: var(--text-primary); white-space: pre-wrap; max-height: 400px; overflow-y: auto; padding-right: 8px;"></div>
            </div>
        </div>
    </div>
</div>

<script>
window._libPlaylist = <?php echo json_encode(array_map(function($s) { $s['image_url'] = $s['image_url'] ?: 'https://picsum.photos/seed/'.$s['id'].'/400/400'; return $s; }, $allSongs)); ?>;
window.currentDetailSongId = null;

// Update sidebar details when song changes via next/prev
window.onSongChange = function(song, index) {
    if (document.getElementById('song-details')?.style.display !== 'block') return;
    const coverUrl = song.image_url || 'https://picsum.photos/seed/' + song.id + '/400/400';
    document.getElementById('detail-image').src = coverUrl;
    document.getElementById('detail-title').innerText = song.title || 'Untitled';
    document.getElementById('detail-tags').innerText = song.tags || 'No tags';
    document.getElementById('detail-lyrics').innerText = song.lyrics || 'No lyrics available.';
    document.getElementById('detail-download-btn').href = 'api/download.php?id=' + song.id;
    window.currentDetailSongId = song.id;
    document.getElementById('detail-play-btn').onclick = () => {
        playSong(song.id, song.title, coverUrl, song.audio_url);
    };
    document.querySelectorAll('.song-row').forEach(row => {
        row.style.borderColor = '';
        row.style.background = '';
    });
    const activeRow = document.querySelector(`.song-row[data-song-id="${song.id}"]`);
    if (activeRow) {
        activeRow.style.borderColor = 'var(--accent-primary)';
        activeRow.style.background = 'var(--bg-tertiary)';
    }
};

function switchLibTab(tab) {
    document.querySelectorAll('.library-tab').forEach(t => t.classList.remove('active'));
    document.querySelector(`.library-tab[data-tab="${tab}"]`).classList.add('active');
    document.getElementById('lib-mine').style.display = tab === 'mine' ? 'block' : 'none';
    document.getElementById('lib-liked').style.display = tab === 'liked' ? 'block' : 'none';
}

function showSongDetails(song, index) {
    const detailsPanel = document.getElementById('song-details');
    detailsPanel.style.display = 'block';
    document.getElementById('details-empty').style.display = 'none';
    const content = document.getElementById('details-content');
    content.style.display = 'flex';

    window.currentDetailSongId = song.id;
    const coverUrl = song.image_url || 'https://picsum.photos/seed/' + song.id + '/400/400';
    document.getElementById('detail-image').src = coverUrl;
    document.getElementById('detail-title').innerText = song.title;
    document.getElementById('detail-tags').innerText = song.tags || 'No tags';
    document.getElementById('detail-lyrics').innerText = song.lyrics || 'No lyrics available.';
    document.getElementById('detail-download-btn').href = 'api/download.php?id=' + song.id;

    document.getElementById('detail-play-btn').onclick = () => {
        playSong(song.id, song.title, coverUrl, song.audio_url);
    };

    if (song.status === 'completed' && song.audio_url) {
        playSong(song.id, song.title, coverUrl, song.audio_url);
    }

    document.querySelectorAll('.song-row').forEach(row => {
        row.style.borderColor = '';
        row.style.background = '';
    });
    const activeRow = document.querySelector(`.song-row[data-song-id="${song.id}"]`);
    if (activeRow) {
        activeRow.style.borderColor = 'var(--accent-primary)';
        activeRow.style.background = 'var(--bg-tertiary)';
    }
}

function buildSongRow(song, index) {
    const cover = song.image_url || 'https://picsum.photos/seed/' + song.id + '/400/400';
    const t = song.title || 'Untitled';
    const meta = song.status === 'completed' ? 'Complete' : (song.status === 'pending' ? 'Generating' : song.status);
    const date = new Date(song.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    let actions = '';
    if (song.status === 'completed') {
        actions = `<button class="icon-btn" onclick="event.stopPropagation(); playSong(${song.id}, '${t.replace(/'/g,"\\'")}', '${cover}', '${song.audio_url}')"><i class="fa-solid fa-play"></i></button>
            <button class="action-btn" onclick="event.stopPropagation(); shareSong(${song.id})" title="Share" style="${song.is_public ? 'color: var(--accent-primary);' : ''}"><i class="fa-solid fa-share-nodes"></i></button>
            <button class="action-btn" onclick="event.stopPropagation(); deleteSong(${song.id})" title="Delete"><i class="fa-solid fa-trash"></i></button>`;
    } else if (song.status === 'pending') {
        actions = `<span class="song-elapsed">0s</span>`;
    }
    return `<div class="song-row" data-song-id="${song.id}" data-status="${song.status}" data-created-at="${song.created_at}" onclick='showSongDetails(${JSON.stringify(song).replace(/'/g,"&#39;")}, ${index})'>
        <div class="song-row-img" style="background-image: url('${cover}');"></div>
        <div class="song-row-info">
            <div class="song-row-title">${t}</div>
            <div class="song-row-meta">${meta} • ${date}</div>
        </div>
        <div class="song-row-actions">${actions}</div>
    </div>`;
}

async function refreshLibrary() {
    try {
        const res = await fetch('api/get_songs.php?user_only=1');
        const data = await res.json();
        const songs = data.songs || [];
        window._libPlaylist = songs.map(s => ({...s, image_url: s.image_url || 'https://picsum.photos/seed/' + s.id + '/400/400'}));

        const container = document.getElementById('lib-mine-list');
        if (!container) return;
        if (!songs.length) {
            container.innerHTML = '';
            document.getElementById('lib-mine').querySelector('div[style*="text-align: center"]')?.remove();
            document.getElementById('lib-mine').insertAdjacentHTML('afterbegin', '<div style="text-align: center; padding: 80px 0; color: var(--text-secondary);"><i class="fa-solid fa-music" style="font-size: 48px; margin-bottom: 16px; display: block;"></i><p>No songs yet.</p></div>');
            return;
        }
        container.innerHTML = songs.map((s, i) => buildSongRow(s, i)).join('');

        // Re-poll pending songs
        songs.filter(s => s.status === 'pending').forEach(s => {
            if (typeof startPendingPoll === 'function') startPendingPoll(s.id, s.title || 'Untitled', s.created_at);
        });
    } catch(e) {}
}

async function shareSong(id) {
    try {
        const res = await fetch('api/toggle_public.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ song_id: id })
        });
        const data = await res.json();
        if(data.success) {
            showToast(data.is_public ? 'Shared to Explore!' : 'Removed from Explore.', 'success');
            refreshLibrary();
        }
    } catch(e) { showToast('Failed to update sharing.', 'error'); }
}

async function deleteSong(id) {
    if(!confirm('Delete this song?')) return;
    try {
        await fetch(`api/delete_song.php?id=${id}`, { method: 'DELETE' });
        showToast('Song deleted.', 'success');
        document.getElementById('song-details').style.display = 'none';
        refreshLibrary();
    } catch(e) { showToast('Failed to delete song.', 'error'); }
}

function playSong(id, title, imgUrl, audioUrl) {
    if (!audioUrl || audioUrl.startsWith('task:')) {
        showToast('This song is still generating...', 'info');
        return;
    }
    if (!audioUrl.startsWith('http')) audioUrl = window.location.origin + window.BASE_URL + '/' + audioUrl;
    const playlist = window._libPlaylist || [];
    const index = playlist.findIndex(s => s.id === id);
    updatePlayer(audioUrl, title, imgUrl, playlist.length ? playlist : [{id, title, audio_url: audioUrl, image_url: imgUrl}], index >= 0 ? index : 0);
}
</script>
