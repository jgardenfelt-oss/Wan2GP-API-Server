<?php
require_once __DIR__ . '/auth.php';

$user = get_current_user_data();
if (!$user) {
    echo '<div style="padding: 24px;">Please log in.</div>';
    exit;
}

$avatar = $user['avatar_url'] ?: 'assets/images/default-avatar.jpg';
?>
<div class="profile-container" style="padding: 24px 0; max-width: 800px;">
    <div style="display: grid; grid-template-columns: 250px 1fr; gap: 40px; background: var(--bg-secondary); padding: 40px; border-radius: 32px; border: 1px solid var(--border-color);">
        
        <!-- Left: Avatar Upload -->
        <div style="text-align: center;">
            <div style="width: 150px; height: 150px; border-radius: 50%; overflow: hidden; margin: 0 auto 20px; border: 4px solid var(--accent-primary); position: relative; group;">
                <img id="profile-preview" src="<?php echo $avatar; ?>" style="width: 100%; height: 100%; object-fit: cover;">
                <label for="avatar-input" style="position: absolute; bottom: 0; left: 0; width: 100%; background: rgba(0,0,0,0.6); padding: 8px; color: white; font-size: 12px; cursor: pointer; transition: opacity 0.3s;">
                    <i class="fa-solid fa-camera"></i> Change
                </label>
                <input type="file" id="avatar-input" style="display: none;" accept="image/*" onchange="previewAvatar(this)">
            </div>
            <h3 style="font-size: 20px; margin-bottom: 4px;"><?php echo htmlspecialchars($user['username']); ?></h3>
            <p style="font-size: 14px; color: var(--text-secondary);"><?php echo htmlspecialchars($user['email']); ?></p>
        </div>

        <!-- Right: Settings Form -->
        <div style="display: flex; flex-direction: column; gap: 24px;">
            <div class="form-group">
                <label style="display: block; font-size: 14px; color: var(--text-secondary); margin-bottom: 8px;">Username</label>
                <input type="text" value="<?php echo htmlspecialchars($user['username']); ?>" disabled style="width: 100%; background: var(--bg-tertiary); border: 1px solid var(--border-color); border-radius: 12px; padding: 12px; color: var(--text-secondary); cursor: not-allowed;">
            </div>

            <div class="form-group">
                <label style="display: block; font-size: 14px; color: var(--text-secondary); margin-bottom: 8px;">New Password</label>
                <input type="password" id="new-password" placeholder="Leave blank to keep current" style="width: 100%; background: var(--bg-tertiary); border: 1px solid var(--border-color); border-radius: 12px; padding: 12px; color: white;">
            </div>

            <div class="form-group">
                <label style="display: block; font-size: 14px; color: var(--text-secondary); margin-bottom: 8px;">Confirm New Password</label>
                <input type="password" id="confirm-password" placeholder="Confirm new password" style="width: 100%; background: var(--bg-tertiary); border: 1px solid var(--border-color); border-radius: 12px; padding: 12px; color: white;">
            </div>

            <button class="btn-primary" onclick="saveProfile()" style="padding: 14px; font-size: 16px; border-radius: 14px; margin-top: 12px;">Save Changes</button>
            <div id="profile-msg" style="margin-top: 12px; font-size: 14px; text-align: center;"></div>
        </div>
    </div>
</div>

<script>
function previewAvatar(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('profile-preview').src = e.target.result;
        }
        reader.readAsDataURL(input.files[0]);
    }
}

async function saveProfile() {
    const password = document.getElementById('new-password').value;
    const confirm = document.getElementById('confirm-password').value;
    const avatarFile = document.getElementById('avatar-input').files[0];
    const msg = document.getElementById('profile-msg');

    if (password && password !== confirm) {
        msg.innerHTML = '<span style="color: #f87171;">Passwords do not match</span>';
        return;
    }

    const formData = new FormData();
    if (password) formData.append('password', password);
    if (avatarFile) formData.append('avatar', avatarFile);

    msg.innerHTML = '<span style="color: var(--text-secondary);">Saving...</span>';

    try {
        const res = await fetch('api/update_profile.php', {
            method: 'POST',
            body: formData
        });
        const data = await res.json();
        if (data.success) {
            msg.innerHTML = '<span style="color: #10b981;">Profile updated successfully!</span>';
            // Update sidebar avatar without reload
            if (data.avatar_url) {
                const sidebarAvatar = document.querySelector('.user-avatar');
                if (sidebarAvatar) {
                    sidebarAvatar.style.backgroundImage = `url('${data.avatar_url}')`;
                    sidebarAvatar.style.backgroundSize = 'cover';
                    sidebarAvatar.style.backgroundPosition = 'center';
                    sidebarAvatar.textContent = '';
                }
            }
        } else {
            msg.innerHTML = `<span style="color: #f87171;">${data.error}</span>`;
        }
    } catch (e) {
        msg.innerHTML = '<span style="color: #f87171;">An error occurred</span>';
    }
}
</script>
