<?php
/**
 * Suno Clone - Secure Auth Library
 */

if (!defined('DB_HOST')) {
    require_once 'config.php';
}

session_start([
    'cookie_httponly' => true,
    'cookie_secure' => defined('SESSION_SECURE') ? SESSION_SECURE : false,
    'cookie_samesite' => 'Lax',
]);

/**
 * Regenerate session ID to prevent session fixation
 */
function secure_login($user_id) {
    session_regenerate_id(true);
    $_SESSION['user_id'] = $user_id;
    $_SESSION['last_regen'] = time();
}

/**
 * Check if user is logged in
 */
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

/**
 * CSRF Token Generation
 */
function generate_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * CSRF Token Verification
 */
function verify_csrf_token($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Register User
 */
function register_user($username, $email, $password) {
    global $pdo;
    
    // Check if this is the first user
    $stmt = $pdo->query("SELECT COUNT(*) FROM users");
    $userCount = $stmt->fetchColumn();
    $isAdmin = ($userCount == 0) ? 1 : 0;
    
    // Hash password using Argon2id if available, otherwise DEFAULT
    $hash = password_hash($password, PASSWORD_ARGON2ID);
    
    $stmt = $pdo->prepare("INSERT INTO users (username, email, password, is_admin, role) VALUES (?, ?, ?, ?, ?)");
    try {
        $role = $isAdmin ? 'admin' : 'user';
        return $stmt->execute([$username, $email, $hash, $isAdmin, $role]);
    } catch (PDOException $e) {
        return false;
    }
}

/**
 * Authenticate User
 */
function login_user($email, $password) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT id, password FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password'])) {
        secure_login($user['id']);
        return true;
    }
    return false;
}

/**
 * Refresh Daily Credits (50 credits every 24h)
 */
function refresh_daily_credits($user_id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT last_credit_update, credits FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    if ($user) {
        $last_update = strtotime($user['last_credit_update']);
        $now = time();
        
        // If more than 24 hours (86400 seconds) have passed
        if ($now - $last_update >= 86400) {
            $stmt = $pdo->prepare("UPDATE users SET credits = credits + 50, last_credit_update = CURRENT_TIMESTAMP WHERE id = ?");
            $stmt->execute([$user_id]);
        }
    }
}

/**
 * Get User Data
 */
function get_current_user_data() {
    global $pdo;
    if (!is_logged_in()) return null;
    
    $user_id = $_SESSION['user_id'];
    refresh_daily_credits($user_id);
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    return $stmt->fetch();
}

/**
 * Get User by Email
 */
function get_user_by_email($email) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    return $stmt->fetch();
}
?>
