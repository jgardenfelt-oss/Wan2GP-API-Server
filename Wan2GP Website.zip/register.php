<?php
require_once 'includes/auth.php';

$error = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = "Security validation failed.";
    } else {
        $username = $_POST['username'] ?? '';
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';
        $accept = isset($_POST['accept_rules']);
        
        if (!$accept) {
            $error = "You must accept the site rules to register.";
        } else {
            // Modify register_user to handle rules_accepted if needed, 
            // or just update it manually after success.
            if (register_user($username, $email, $password)) {
                // Auto-accept rules for new registration
                $stmt = $pdo->prepare("UPDATE users SET rules_accepted = 1 WHERE email = ?");
                $stmt->execute([$email]);
                $success = "Registration successful! <a href='login.php'>Login here</a>";
            } else {
                $error = "Username or Email already exists.";
            }
        }
    }
}
$csrf_token = generate_csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - Wan2GP</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/main.css">
    <?php $stmt = $pdo->query("SELECT setting_value FROM site_settings WHERE setting_key = 'active_skin'"); $sk = $stmt->fetchColumn() ?: 'default'; if (file_exists(__DIR__ . '/skins/' . $sk . '/skin.css')): ?>
    <link rel="stylesheet" href="skins/<?php echo $sk; ?>/skin.css">
    <?php endif; ?>
    <style>
        body { display: flex; align-items: center; justify-content: center; height: 100vh; background: radial-gradient(circle at top left, #1a1a1a, #0a0a0a); }
        .auth-card { background: var(--bg-secondary); padding: 48px; border-radius: 32px; border: 1px solid var(--border-color); width: 100%; max-width: 420px; box-shadow: 0 40px 100px rgba(0,0,0,0.8); }
        .auth-card h1 { margin-bottom: 8px; font-weight: 800; font-size: 32px; }
        .auth-card p { color: var(--text-secondary); margin-bottom: 32px; }
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 10px; font-size: 14px; color: var(--text-secondary); }
        input { width: 100%; background: var(--bg-tertiary); border: 1px solid var(--border-color); padding: 14px 18px; border-radius: 16px; color: white; font-size: 16px; transition: all 0.3s; }
        input:focus { border-color: var(--accent-primary); outline: none; box-shadow: 0 0 0 4px rgba(236, 72, 153, 0.1); }
        .btn-auth { width: 100%; margin-top: 10px; font-size: 16px; padding: 16px; }
        .auth-footer { margin-top: 24px; text-align: center; color: var(--text-secondary); font-size: 14px; }
        .auth-footer a { color: var(--accent-primary); text-decoration: none; font-weight: 600; }
        .error-msg { background: rgba(248, 113, 113, 0.1); color: #f87171; padding: 12px; border-radius: 12px; margin-bottom: 20px; font-size: 14px; text-align: center; border: 1px solid rgba(248, 113, 113, 0.2); }
        .success-msg { background: rgba(74, 222, 128, 0.1); color: #4ade80; padding: 12px; border-radius: 12px; margin-bottom: 20px; font-size: 14px; text-align: center; border: 1px solid rgba(74, 222, 128, 0.2); }
    </style>
</head>
<body>
    <div class="auth-card">
        <div class="logo">Wan2GP</div>
        <h1>Create account</h1>
        <p>Start generating music today.</p>
        
        <?php if($error): ?> <div class="error-msg"><?php echo $error; ?></div> <?php endif; ?>
        <?php if($success): ?> <div class="success-msg"><?php echo $success; ?></div> <?php endif; ?>

        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" placeholder="johndoe" required>
            </div>
            <div class="form-group">
                <label>Email Address</label>
                <input type="email" name="email" placeholder="name@example.com" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="••••••••" required>
            </div>
            <div class="form-group" style="display: flex; align-items: flex-start; gap: 10px; margin-top: 24px;">
                <input type="checkbox" name="accept_rules" id="accept_rules" required style="width: 20px; height: 20px; margin: 0; cursor: pointer;">
                <label for="accept_rules" style="margin: 0; cursor: pointer; line-height: 1.4;">
                    I have read and accept the <a href="#" onclick="showRules()" style="color: var(--accent-primary); text-decoration: none; font-weight: 600;">Site Rules & Terms</a>
                </label>
            </div>
            <button type="submit" class="btn-primary btn-auth">Sign Up</button>
        </form>

        <!-- Rules Modal -->
        <?php 
            $stmt = $pdo->query("SELECT setting_value FROM site_settings WHERE setting_key = 'site_rules'");
            $rules_text = $stmt->fetchColumn() ?: 'Please follow the site rules.';
        ?>
        <div id="rules-modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.9); align-items: center; justify-content: center; z-index: 9999; backdrop-filter: blur(12px); padding: 20px;">
            <div style="background: var(--bg-secondary); padding: 40px; border-radius: 40px; max-width: 600px; width: 100%; border: 1px solid var(--border-color); box-shadow: 0 30px 60px rgba(0,0,0,0.6); display: flex; flex-direction: column; max-height: 80vh;">
                <h2 style="font-size: 24px; font-weight: 800; margin-bottom: 20px;">Site Rules & Terms</h2>
                <div class="custom-scrollbar" style="background: var(--bg-tertiary); padding: 24px; border-radius: 20px; margin-bottom: 24px; font-size: 15px; line-height: 1.8; color: var(--text-secondary); overflow-y: auto; flex: 1; white-space: pre-wrap; text-align: left;">
                    <?php echo htmlspecialchars($rules_text); ?>
                </div>
                <button class="btn-primary" style="width: 100%; padding: 16px; font-size: 16px; border-radius: 16px;" onclick="hideRules()">Close</button>
            </div>
        </div>

        <script>
        function showRules() { document.getElementById('rules-modal').style.display = 'flex'; }
        function hideRules() { document.getElementById('rules-modal').style.display = 'none'; }
        </script>
        <style>
        .custom-scrollbar::-webkit-scrollbar { width: 6px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 10px; }
        </style>

        <div class="auth-footer">
            Already have an account? <a href="login.php">Log in</a>
        </div>
    </div>
</body>
</html>
